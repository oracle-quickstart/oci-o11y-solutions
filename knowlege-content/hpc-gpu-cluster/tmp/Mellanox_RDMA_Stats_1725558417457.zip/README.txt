Content
Sources: [Mellanox RDMA Stats]
Parsers: [Mellanox Network Checks and Stats]
Fields: [GPU Count, GPU Model, Metric Name]

Reference
Fields: [availdomain, clnthostname, dev, hwid, instid, mbody, mlogent, msg, mtgt, nodedisplayname, value]
