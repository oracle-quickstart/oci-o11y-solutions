Content
Sources: [SLURM SQUEUE]
Parsers: [SLURM SQUEUE PIPE]
Fields: [Cores Count, Is Oversubscribed, Job Name, Minimum CPUS Requested, Node Count, Nodes Requested, Quality of Service, Reservation, SLURM Node Socket Cores Threads, SLURM Nodes, Slurm Job Priority, Temporary Disk space (MB), Threads Count, Time Limit, Workload Characterization Key]

Reference
Fields: [cmd, comment, completetime, dir, elaptimesys, jobid, key, mbody, memalloc, nodedisplayname, olsparentgrp, partition, pri, reas, starttime, statecurr, usrid, usrlogonid]
