Content
Sources: [Mellanox Troubleshooting Codes v1]
Parsers: [Mellanox Network Checks and Stats]
Fields: [GPU Count, GPU Model, Vendor]

Reference
Fields: [availdomain, clnthostname, dev, hwid, instid, mbody, mlogent, msg, mtgt, nodedisplayname, serialnum]
