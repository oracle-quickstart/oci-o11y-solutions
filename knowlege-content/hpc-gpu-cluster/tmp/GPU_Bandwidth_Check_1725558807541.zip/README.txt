Content
Sources: [GPU Bandwidth Check]
Parsers: [Test GPU Checks]
Labels: [#check_failed]
Fields: [BandWidth DtoH, BandWidth HtoD, GPU Count, GPU Model, GPU Xid Error Code]

Reference
Fields: [availdomain, dev, errtext, hwid, instid, mbody, mlogent, msg, mtag, mtgt, nodedisplayname, sevlvl, status, test]
