Content
Sources: [SLURM SINFO]
Parsers: [SLURM SINFO (CSV comma)]
Fields: [Cores Count, Features Available, Is Oversubscribed, Job Size, Node Count, Reservation, Root Restricted Partition, Socket Count, Temporary Disk space (MB), Threads Count, Time Limit, Weight]

Reference
Fields: [avlblstatus, cpucnt, mbody, memcapki, node, nodedisplayname, partition, reas, statecurr, usergroups]
