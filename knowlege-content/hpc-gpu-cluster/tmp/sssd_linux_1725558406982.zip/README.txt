Content
Sources: [sssd linux]
Parsers: [SSSD Logs]

Reference
Fields: [comp, mbody, msg, mtgt, nodedisplayname, oper]
