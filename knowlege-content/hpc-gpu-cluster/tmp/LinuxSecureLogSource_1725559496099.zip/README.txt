Content
Sources: [LinuxSecureLogSource]

Reference
Parsers: [host_syslog_logtype]
Fields: [mtgt, nodedisplayname]
