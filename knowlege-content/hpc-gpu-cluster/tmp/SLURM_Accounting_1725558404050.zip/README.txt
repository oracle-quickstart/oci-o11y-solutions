Content
Sources: [SLURM Accounting]
Parsers: [SLURM Accounting Logs (CSV)]
Fields: [Allocated CPUs, Allocated Nodes, Allocated TRES, CPU IDs, CPU Requested (TRES), CPU Time (SLURM), CPU Time Raw, Execution Eligible Time, Failed Node, Generic Resources GPU Requested (TRES), Job Name, Job Submit Time, Layout, Memory Requested (TRES), NNodes, Nodes Requsted (TRES), Planned CPU (SLURM format), Planned CPU RAW (Seconds), Planned Wall Clock Time, Quality of Service, Reservation, SLURM Job Elapsed Time, SLURM Nodes List, Slurm Job Priority, Task count, Time Limit]

Reference
Fields: [clusterid, cmd, comment, completetime, configuredlimit, constrainttype, cpucnt, cpuusrpercent, dir, elaptimereal, exitcode, flags, group, jobid, mbody, msginfo, nodedisplayname, partition, reas, starttime, statecurr, subsys, suspend, tcpresflag, usrgrpid, usrid, usrname]
