Content
Sources: [LinuxSyslogSource]

Reference
Parsers: [host_syslog_logtype]
Fields: [mtgt, nodedisplayname]
