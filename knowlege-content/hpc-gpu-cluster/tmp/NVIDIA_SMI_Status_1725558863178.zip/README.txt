Content
Sources: [NVIDIA SMI Status]
Parsers: [NVIDIA SMI Status]
Fields: [Clocks Event Reasons Active, Clocks current graphics (MHz), Clocks current memory (MHz), Clocks current sm (MHz), Clocks default_applications graphics (MHz), Clocks default_applications memory (MHz), Event GPU Idle , GPU Count, GPU Model, GPU Temperature, GPU Temperature tlimit, GPU Utilization, GPU Utulization, Hardwaer Power Brake Slowdown, Hardware Slowdown, Hardware Thermal Slowdown, Memory Temperature, Memory Utilization, PCI Bus ID, Power Draw (W), Software Power Cap, Software Thermal Slowdown]

Reference
Fields: [availdomain, hwid, instid, mbody, memusenow, mlogent, mtgt, nodedisplayname, serialnum, time]
