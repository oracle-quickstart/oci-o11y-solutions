Content
Sources: [AuditLogSource]

Reference
Parsers: [host_auditlog_logtype]
