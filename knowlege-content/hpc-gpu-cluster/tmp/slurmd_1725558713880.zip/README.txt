Content
Sources: [slurmd]
Parsers: [slurmtest]

Reference
Labels: [actninterr, actnstart, actnstop, actnsucc]
Fields: [jobid, mbody, msg, msgtype, mtag, task, usrgrpid, usrid]
