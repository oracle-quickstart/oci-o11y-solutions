Content
Sources: [SLURM Control Jobs]
Parsers: [scontrol header, scontrol show jobs file]
Fields: [Batch Host, Billing Resouce Allocated (TRES), Billing Resouce Requested (TRES), CPU IDs, CPU Requested (TRES), CPU count per task, CPUs Allocated (TRES), Core Spec, Generic Resources, Generic Resources GPU Allocated (TRES), Generic Resources GPU Requested (TRES), JOB Generic Resources, Job Dependency, Job Minimum Time Limit (SLURM), Job Name, Job Preemtion Eligible Time, Job Preemtion Time, Job Run Time (SLURM), Job Submit Time, Job Suspend Time, Last Schedule Evaluation Time, MCS Label, Memory Allocated (TRES), Memory Requested (TRES), Minimum CPUs (Node), Minimum Memory (Node), Minimum Temporary Disk (Node), Node Count, Nodes Allocated (TRES), Nodes Requsted (TRES), Oversubscribe, Quality of Service, Reboot, Requeue, SLURM Node Allocator Name, SLURM Node Socket Cores Threads, SLURM Nodes, SLURM Nodes List, Slurm Job Priority, Socket Count, Task count, Time Limit]

Reference
Fields: [account, batch, cmd, completetime, cpucnt, dir, exitcode, group, jobid, mbody, memtot, nentries, nicevalue, nodedisplayname, partition, reas, restartcount, schedulername, starttime, statecurr, usrgrpid, usrid, usrname]
