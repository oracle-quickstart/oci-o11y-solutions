Content
Sources: [Mellanox Phy Ber v1]
Parsers: [Mellanox Network Checks and Stats]
Fields: [GPU Count, GPU Model, Vendor]

Reference
Fields: [availdomain, clnthostname, dev, hwid, instid, mbody, mlogent, msg, mtgt, nodedisplayname, serialnum, test, value]
