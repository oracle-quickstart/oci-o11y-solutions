Content
Sources: [SLURM scontrol nodes]
Parsers: [Copy of scontrol nodes file, scontrol header]
Labels: [#node_not_available, #resource_available]
Fields: [ALLOCATED, ALLOCATED_PLUS, BLOCKED, Billing Resource Allocatable, COMPLETING, CPU Usage, CPUs Allocated (TRES), DOWN, DRAINED, DRAINING, FAIL, FAILING, FUTURE, Features Available, Generic Resource GPU Allocatable, Generic Resources, Generic Resources GPU Requested (TRES), IDLE, INVAL, JOB Generic Resources, MAINT, MIXED, Memory Allocated (TRES), Node State, PERFCTRS (NPC), PLANNED, POWERED_DOWN, POWERING_DOWN, POWERING_UP, POWER_DOWN, Partitions List, REBOOT_ISSUED, REBOOT_REQUESTED, RESERVED, SLURM  cores per socket, UNKNOWN, Weight]

Reference
Labels: [1, False, MAINT, True]
Fields: [adapt, additionalinfo, architecture, avlblstatus, cpuallocatable, cpucapacity, hostip, lasteventtime, mbody, memallocatableki, memavail, msg, mtag, node, nodedisplayname, reas, srvrhostname]
