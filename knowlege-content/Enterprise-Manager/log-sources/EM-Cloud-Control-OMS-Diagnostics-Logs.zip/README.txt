Content
Sources: [EM Cloud Control OMS Diagnostics Logs]
Parsers: [EM Cloud Control OMS Diagnostic Log Format]

Reference
Fields: [ecidid, mbody, mod, msg, sevlvl, thread, usrname, wlsserver]
