Content
Sources: [EMCC OMS EMCTL Logs]
Parsers: [EM Cloud Control OMS EMCTL Log Format]

Reference
Fields: [mbody, msg, sevlvl, thread]
