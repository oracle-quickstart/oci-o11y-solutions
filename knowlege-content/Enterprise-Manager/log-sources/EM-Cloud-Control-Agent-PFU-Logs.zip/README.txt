Content
Sources: [EM Cloud Control Agent PFU Logs]
Parsers: [EM Cloud Control Agent PFU Log Format]

Reference
Fields: [mbody, msg]
