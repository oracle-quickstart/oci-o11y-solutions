Content
Sources: [EM Cloud Control Agent EMCTL Logs]
Parsers: [EM Cloud Control Agent EMCTL Log Format]

Reference
Fields: [mbody, msg, ospid]
