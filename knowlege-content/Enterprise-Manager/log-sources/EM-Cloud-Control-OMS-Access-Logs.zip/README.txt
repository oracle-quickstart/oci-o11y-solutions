Content
Sources: [EM Cloud Control OMS Access Logs]
Parsers: [EM Cloud Control OMS Access Log Format]

Reference
Fields: [contsz, ecidid, ecidrelid, mbody, method, statcode, uri]
