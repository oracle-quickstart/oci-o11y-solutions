Content
Sources: [EM Cloud Control Agent JVMGC Logs]
Parsers: [EM Cloud Control Agent Java Garbage Collection Log Format]

Reference
Fields: [mbody, msg]
