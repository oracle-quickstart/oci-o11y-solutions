Content
Sources: [EM Cloud Control Agent Host Target Event Logs]
Parsers: [EM Cloud Control Agent Host Target Event Log Format]

Reference
Fields: [mbody, msg, sevlvl]
