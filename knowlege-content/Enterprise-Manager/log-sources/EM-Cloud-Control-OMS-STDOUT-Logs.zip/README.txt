Content
Sources: [EM Cloud Control OMS STDOUT Logs]
Parsers: [EM Cloud Control OMS STDOUT Log Format]

Reference
Fields: [errid, mbody, mod, msg, sevlvl]
