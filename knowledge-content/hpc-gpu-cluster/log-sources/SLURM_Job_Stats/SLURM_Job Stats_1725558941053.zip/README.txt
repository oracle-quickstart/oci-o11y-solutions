Content
Sources: [SLURM Job Stats]
Parsers: [SLURM Stats]

Reference
Fields: [jobid, mbody]
