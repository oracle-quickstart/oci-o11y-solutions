Content
Sources: [OCI Integration Audit Logs]
Parsers: [OCI Integration Audit Log Format]

Reference
Fields: [audref, firstevnttime, mbody, ocirsrcname, rsrcid, rsrcops, rsrctype, rsrcver, usrname]
