Content
Sources: [ociK8sContGenLogsSource]
Fields: [Currency, ProductId, Quantity, email]

Reference
Fields: [container, cost, mbody]
