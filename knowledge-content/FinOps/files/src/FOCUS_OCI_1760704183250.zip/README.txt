Content
Sources: [FOCUS_OCI]
Parsers: [FOCUS_OCI]
Fields: [BilledCost, BillingAccountId, BillingAccountName, BillingCurrency, BillingPeriodEnd, BillingPeriodStart, ChargeCategory, ChargeDescription, ChargeFrequency, ChargePeriodEnd, ChargeSubCategory, CommitmentDiscountCategory, CommitmentDiscountId, CommitmentDiscountName, CommitmentDiscountType, EffectiveCost, InvoiceIssuer, ListCost, ListUnitPrice, PricingCategory, PricingQuantity, PricingUnit, Publisher, ResourceId, ResourceName, ResourceType, ServiceCategory, ServiceName, SkuPriceId, SubAccountId, Tags, UsageQuantity, UsageUnit, lAvailabilityZone, oci_AttributedCost, oci_AttributedUsage, oci_BackReferenceNumber, oci_BilledQuantityOverage, oci_CompartmentId, oci_CompartmentName, oci_CostOverage, oci_OverageFlag, oci_ReferenceNumber, oci_UnitPriceOverage, skuID, subAccountName]

Reference
Fields: [mbody, provider, region, time]
