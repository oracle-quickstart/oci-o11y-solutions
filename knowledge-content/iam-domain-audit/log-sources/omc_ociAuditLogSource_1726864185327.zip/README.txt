Content
Sources: [omc_ociAuditLogSource]

Reference
Parsers: [oci_audit_unifmt_logtype]
Functions: [Geolocation, Lookup]
Fields: [actntype, appid, cityclnt, comment, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, desc, eventdesc, geolocclnt, mbody, regionclnt, regioncodeclnt, srcip, type]
Lookups: [omc_audit_api_names]
