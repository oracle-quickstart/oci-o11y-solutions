Content
Sources: [EMCC Agent STDOUT Logs]
Parsers: [EM Cloud Control Agent Nohup Log Format]

Reference
Fields: [mbody, msg, ospid]
