Content
Sources: [EMCC Agent Logs]
Parsers: [EM Cloud Control Agent Log Format]

Reference
Labels: [applerr, commerr, connerr, datainc, oom]
Fields: [mbody, msg, mtag, sevlvl, thread]
