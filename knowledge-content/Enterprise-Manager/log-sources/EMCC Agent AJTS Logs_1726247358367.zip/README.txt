Content
Sources: [EMCC Agent AJTS Logs]
Parsers: [EM Cloud Control Agent AJTS Log Format]

Reference
Fields: [mbody, msg]
