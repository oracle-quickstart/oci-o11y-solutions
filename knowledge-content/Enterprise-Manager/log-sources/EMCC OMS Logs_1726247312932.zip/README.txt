Content
Sources: [EMCC OMS Logs]
Parsers: [EM Cloud Control OMS Log Format]

Reference
Labels: [applerr, connerr, datainc, httperr, sockettimeout, timeout]
Fields: [linenum, mbody, method, mod, msg, mtag, sevlvl, thread]
