Content
Sources: [OCI_Backup_Duration]
Parsers: [OCI_Backup_Duration]
Fields: [BackupDestinationType, Metric_Name, Metric_Value, Timestamp, resourceGroup]

Reference
Fields: [compartmentid, desc, mbody, namespace, ocirsrcname, unit]
