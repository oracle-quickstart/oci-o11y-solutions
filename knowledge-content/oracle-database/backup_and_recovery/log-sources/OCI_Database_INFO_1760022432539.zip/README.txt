Content
Sources: [OCI_Database_INFO]
Parsers: [OCI DB Meta]
Fields: [DBUniqueName, LifecycleState, ResourceDate, ResourceOwner, autoBackupEnabled, autoBackupWindow, autoFullBackupDay, autoFullBackupWindow, backupDeletionPolicy, characterSet, dbrsId, dbrsPolicyId, isCdb, isDgEnabled, isRemote, isZeroDataLossEnabled, kmsKeyId, lastBackupDurationInSeconds, lastBackupTimestamp, lastFailedBackupTimestamp, lastRemoteBackupTimestamp, pdbName, recoveryWindowInDays, timeCreated]

Reference
Fields: [compartmentid, dbname, mbody, ocirsrcocid, orahome, org, type]
