Content
Sources: [OCI_DB_recovery_Logs]
Parsers: [OCI DB Recovery logs]
Fields: [DBUniqueName, LifecycleState, ResourceDate, ResourceOwner, backupCloudLocation, backupSpaceEstimateInGBs, backupSpaceUsedInGBs, currentRetentionPeriod, currentRetentionPeriodInDays, currentRetentionPeriodInSeconds, databaseSize, dbCloudLocation, dbSizeInGBs, health, healthDetails, isReadOnlyResource, isRedoLogsEnabled, minimumRecoveryNeededInDays, rcvCloudLocation, retentionPeriodInDays, timeCreated, timeUpdated, unprotectedWindow, unprotectedWindowInSeconds, vpcUserName]

Reference
Fields: [compartmentid, dbid, dbname, lifecycledetail, mbody, ocirsrcocid, ocisubnetocid, org, polid, project]
