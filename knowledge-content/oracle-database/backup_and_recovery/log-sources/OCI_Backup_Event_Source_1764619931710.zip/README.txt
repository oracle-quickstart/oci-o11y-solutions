Content
Sources: [OCI_Backup_Event_Source]
Parsers: [OCI_Backup_Event]
Fields: [BackupDestinationType, DBUniqueName, DatabaseEdition, LifecycleState, additionalDetails, autoBackupEnabled, backupState, backupType, databaseId, dbHomeId, dbSystemId, dbVersion, isCdb, recoveryWindowInDays, sourceType, timeCreated, timeUpdated, volumeId, volumeName]

Reference
Fields: [availdomain, compartmentid, compartmentname, data, datasrc, eventid, eventtype, mbody, ocirsrcname, starteventtime, status]
