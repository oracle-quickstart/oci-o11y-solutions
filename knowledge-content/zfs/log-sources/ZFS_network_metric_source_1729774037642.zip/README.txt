Content
Sources: [ZFS_network_metric_source]
Parsers: [ZFSTimeParser, ZFS_network_metric_parser]
Fields: [Network Throughput Bytes]

Reference
Fields: [mbody]
