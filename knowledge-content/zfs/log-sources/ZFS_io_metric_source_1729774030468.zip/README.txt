Content
Sources: [ZFS_io_metric_source]
Parsers: [ZFSTimeParser, ZFS_io_metric_parser]

Reference
Fields: [diskcurio, mbody]
