Content
Sources: [ZFS_audit_log_source]
Parsers: [ZFSTimeParser, ZFS_audit_log_parser]
Fields: [Audit Annotation]

Reference
Fields: [actnuser, mbody, msg, srcip]
