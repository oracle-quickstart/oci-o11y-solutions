Content
Sources: [ZFS_cpuutil_metric_source]
Parsers: [ZFSTimeParser, ZFS_cpuutil_metric_parser]

Reference
Fields: [cpuusagepercent, mbody]
