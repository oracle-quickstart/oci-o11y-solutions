Content
Sources: [ZFS_alert_log_source]
Parsers: [ZFSTimeParser, ZFS_alert_log_parser]
Fields: [Alert Severity Text]

Reference
Fields: [alertname, mbody, msg, systemuuid]
