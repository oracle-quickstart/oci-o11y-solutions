Content
Sources: [Fusion_ESSHealthRPT_SOAP]
Parsers: [Fusion_ESSHealthRPT_Decoded_XML, Fusion_ESSHealthRPT_SOAP_ReportBytes_XML]
Fields: [FusionCompletetime, FusionLastRunEndTime, FusionStartTime, FusionlastRunTimestamp, FusionlastSuccessTimestamp, Product Family Name, Product Name, adhocCount, avgRuntimeBaselineMinutes, avgRuntimeMinutes, blockedRuns, cancelledRuns, confidenceScoreWeighted, currentlyRunningCount, failedRuns, failuresLast24Hours, failuresLast7Days, jobRiskScore, lastRuntimeMinutes, maxRunningDurationHours, p95RuntimeBaselineMinutes, predictedFailureProbability, previousRuntimeMinutes, queuePressure, runningRuns, runtimeTrendSlopePerRun, runtimeVolatilityIndex, scheduleEndTime, scheduleInterval, scheduleStartTime, scheduledCount, slaBreachProbability, stddevRuntimeMinutes, stuckJobProbability, succeededRuns, totalRuns, warningRuns]

Reference
Functions: [Lookup]
Fields: [alarmstatus, cause, depapp, freq, job, jobdefid, jobid, lastid, mbody, parentreqid, procgrp, prodfamilycode, product, reqid, reqtype, sbmtr, schedtype, sevlvl, status, time]
Lookups: [Fusion_Products_Lookup]
