Content
Sources: [Fusion BIP Audit SOAP]
Parsers: [Fusion_BIP_Decoded_XML_Parser, Fusion_BIP_SOAP_ReportBytes_XML]
Fields: [Application Name, Cache Status, Job Completion Time, Job Start Time, Partitions List, Record Count, Service Name, Session ID, TenantId]

Reference
Fields: [dur, ecidid, format, mbody, model, path, recid, rowsexamined, status, totaltime, type, usrname]
