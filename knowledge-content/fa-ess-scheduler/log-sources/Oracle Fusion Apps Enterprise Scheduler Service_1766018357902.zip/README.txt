Content
Sources: [Oracle Fusion Apps: Enterprise Scheduler Service]
Parsers: [Fusion Apps: ESS Requests]
Fields: [Cause Description, Deployed Application Name, ESS Requested Start Time, ESS Schedule Name, ElapsedTime, Enterprise ID, Exec Attempt, Execution Mode, Execution Type, Frequency, Instance Parent Id, Is Async Recoverable, Is Cancellable, Is Force Cancel Allowed, Is Holdable, Is Recoverable, Is Timed Out, Job Definition Id, Job Description, Job Display Name, Job Type, Last Schedule Instance Id, Last Sub Request Set, Links, Parent Exec Attempt, Paused Count, Process Group, Process Phase, Process Phase Description, Product, Product Family, Product Name, Recurrences, Request Mode, Request Parameter Name, Request Parameter Type, Request Parameter Values, Request Parameters, Request Type, Retried Count, Run As User, Schedule Description, Schedule Display Name, Scheduled Time, State, State Description, StateChange Time, Step Id, Sub Request Set, Submitter, Submitter Dms RID, Submitter DmsECID, Submitter GUID, dmsRID, ical schedule interval]

Reference
Fields: [app, attempts, desc, ecidid, eventdesc, flowid, mbody, objselflink, parentreqid, pri, reqid, schedule, stateprev, time]
Lookups: [Fusion Products and Product Family]
