Content
Sources: [Fusion_ESS_Job_Health_Source_V30]
Parsers: [Fusion_ESS_Job_Health_JSON_Parser_V5]
Fields: [FusionApplication, FusionCompletetime, FusionLastRunEndTime, FusionParentRequestID, FusionProcessGroup, FusionProduct, FusionRequestID, FusionStartTime, FusionSubmitter, FusionlastRunTimestamp, FusionlastSuccessTimestamp, JobAlertSeverity, adhocCount, alertFlag, alertReason, attributeName1, attributeName2, attributeName3, attributeName4, attributeName5, attributeVal1, attributeVal2, attributeVal3, attributeVal4, attributeVal5, avgRuntimeBaselineMinutes, avgRuntimeMinutes, blockedRuns, cancelledRuns, confidenceLevel, confidenceScoreWeighted, currentlyRunningCount, failedRuns, failuresLast24Hours, failuresLast7Days, highFrequencyScheduleFlag, jobIdentifier, jobName, jobRiskScore, lastFailedRequestId, lastRequestId, lastRuntimeMinutes, lastSuccessRequestId, longestRunningRequestId, maxRunningDurationHours, p95RuntimeBaselineMinutes, predictedFailureProbability, previousRuntimeMinutes, queuePressure, requestType, runningRuns, runtimeRegressionStatus, runtimeTrendSlopePerRun, runtimeVolatilityIndex, scheduleEndTime, scheduleEndedFlag, scheduleFrequency, scheduleInterval, scheduleOverdueFlag, scheduleStartTime, scheduledCount, slaBreachProbability, stddevRuntimeMinutes, stuckJobProbability, succeededRuns, totalRuns, warningRuns]

Reference
Fields: [mbody, time]
