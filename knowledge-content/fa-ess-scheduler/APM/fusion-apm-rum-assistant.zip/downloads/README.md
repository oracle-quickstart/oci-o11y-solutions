# Downloads

Store input material for a generation run here, including:

- the latest Visual Builder extension export ZIP;
- `app-ui-info.json` or an approved HAR used for discovery; and
- a manually downloaded `apmrum.fus.base.combi.min.js`, when required.

When `--app-ui-info-url` is used, the generator saves the validated catalog as
`config/app-ui-info.json`, next to the deployment configuration. If
authentication prevents the generator from downloading it, save the response
there manually and use `--app-ui-info-file config/app-ui-info.json`.

When this directory contains exactly one ZIP, the generator selects it
automatically. The macOS and Windows assistant launchers show a numbered list
when several ZIPs are present, so you can choose the intended Fusion export.

These files can contain customer source, environment metadata, or session
information. They are ignored by Git by default.
