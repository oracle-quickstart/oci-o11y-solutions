#!/usr/bin/env python3
"""Generate a Fusion extension export with APM RUM enabled in every App UI."""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse


AGENT_NAME = "apmrum.fus.base.combi.min.js"
MODULE_ALIAS = "apmRum"
MODULE_PATH = "self:$functions/apmRum"
VB_ENTER_CHAIN_ID = "apmRumVbEnterListener"
INITIALIZATION_MODE_ENV = "APM_RUM_INITIALIZATION_MODE"
PACKAGE_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "apm-rum-config.json"
EXAMPLE_CONFIG = PACKAGE_ROOT / "config" / "apm-rum-config.example.json"
DEFAULT_DOWNLOADS = PACKAGE_ROOT / "downloads"
DEFAULT_OUTPUT = PACKAGE_ROOT / "output"
DEFAULT_CATALOG = DEFAULT_CONFIG.parent / "app-ui-info.json"
EXAMPLE_APP_UI_INFO_URL = (
    "https://eeho.fa.us2.oraclecloud.com/fscmRestApi/vxmanifest/v2/digests/"
    "latest?type=app-ui-info"
)
PILLAR_LABELS = {
    "cx": "Customer Experience (CX)",
    "erp": "Enterprise Resource Planning (ERP)",
    "hcm": "Human Capital Management (HCM)",
    "scm": "Supply Chain Management (SCM)",
}
PROVIDER_PILLAR_PREFIXES = (
    ("oracle_hcm_", "hcm"),
    ("oracle_cx_", "cx"),
    ("oracle_scm_", "scm"),
    ("oracle_prc_", "scm"),
    ("oracle_erp_", "erp"),
    ("oracle_fin_", "erp"),
)
# Fusion documentation explicitly excludes this Redwood application from APM
# customization. Keep the guard in the generator as well as in the guide.
UNIFIED_MODULE_APPLICATION_IDS = {"unified-module", "unified_module", "unifiedmodule"}


@dataclass(frozen=True)
class ExtensionContext:
    root: Path
    manifest_path: Path
    manifest_name: str
    extension_id: str
    extension_version: str
    source_version: str | None
    manifest_sha256: str
    manifest: dict[str, object]

    @property
    def identifier(self) -> str:
        source_suffix = f"+source.{self.source_version}" if self.source_version else ""
        return f"{self.extension_id}@{self.extension_version}{source_suffix}"

    @property
    def format_identifier(self) -> str:
        return (
            "legacy-extension-json"
            if self.manifest_name == "extension.json"
            else "vb-extension-json"
        )


@dataclass(frozen=True)
class PillarSuggestion:
    pillar: str
    confidence: str
    evidence: str

    @property
    def label(self) -> str:
        return PILLAR_LABELS.get(self.pillar, self.pillar)


@dataclass(frozen=True)
class CatalogApplication:
    provider_id: str
    provider_version: str
    application_id: str
    url_id: str
    display_name: str
    pillar: str
    extensible: bool


def parse_bool(value: object, field: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    raise ValueError(f"{field} must be true or false")


def load_config(path: Path) -> dict[str, object]:
    if path.exists():
        with path.open(encoding="utf-8") as stream:
            config = json.load(stream)
        if not isinstance(config, dict):
            raise ValueError("The configuration file must contain a JSON object")
    else:
        config = {}

    try:
        validate_config(config)
        agent_url(config, None)
        return config
    except ValueError as configuration_error:
        if not sys.stdin.isatty():
            if path.exists():
                raise configuration_error
            raise ValueError(
                f"No usable configuration was found at {path}. Run the assistant "
                "interactively to enter the first-time APM settings."
            ) from configuration_error

        return prompt_for_config(path, config, configuration_error)


def prompt_value(label: str, default: str = "", required: bool = False) -> str:
    """Ask a first-time administrator for a single configuration value."""
    while True:
        suffix = f" [{default}]" if default else ""
        value = input(f"{label}{suffix}: ").strip()
        if not value:
            value = default
        if value or not required:
            return value
        print("This value is required.")


def validate_prompt_value(value: str, validator) -> str:
    """Validate one interactive answer without making the user restart setup."""
    try:
        validator(value)
    except ValueError as error:
        print(f"That value cannot be used: {error}")
        return ""
    return value


def prompt_validated_value(label: str, validator, default: str = "") -> str:
    while True:
        value = prompt_value(label, default, required=True)
        if validate_prompt_value(value, validator):
            return value


def prompt_yes_no(label: str, default: bool = False) -> bool:
    default_label = "Y/n" if default else "y/N"
    while True:
        value = input(f"{label} [{default_label}]: ").strip().lower()
        if not value:
            return default
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        print("Enter y or n.")


def validate_public_data_key(value: str) -> None:
    if not value.strip():
        raise ValueError("the APM public data key is required")
    if re.search(r"<[^>]+>", value):
        raise ValueError("replace the example placeholder with the APM public data key")


def validate_upload_endpoint(value: str) -> None:
    parsed = urlparse(value.strip())
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("enter the HTTPS data upload endpoint from the APM domain")
    if parsed.username or parsed.password:
        raise ValueError("the endpoint must not include a user name or password")


def validate_agent_region(value: str) -> None:
    if not re.fullmatch(r"[a-z]{2}-[a-z0-9-]+-[0-9]+", value.strip()):
        raise ValueError("enter an OCI region such as us-phoenix-1")


def prompt_for_config(
    path: Path, existing: dict[str, object], reason: ValueError
) -> dict[str, object]:
    """Create or complete the deployment-local configuration without JSON editing."""
    print("\nAPM RUM setup")
    print("Before continuing, open the target APM domain in the OCI Console.")
    print("You need these three values:")
    print("  1. OCI region: shown in the Console region selector for the APM domain.")
    print("  2. Public data key: APM domain details > Data Keys > Public Data Key.")
    print("  3. Data upload endpoint: shown in the APM domain details.")
    print("Privacy collection stays off by default. Enable it later only by editing "
          "the configuration file after the required review.")
    print("The values entered here are saved only in this assistant folder for later runs.")
    if path.exists():
        print(f"The existing configuration needs attention: {reason}")
    else:
        print("No configuration file was found, so this is the one-time setup.")

    def usable_default(name: str, fallback: str = "") -> str:
        value = str(existing.get(name, fallback)).strip()
        return "" if re.search(r"<[^>]+>", value) else value

    def existing_or_prompt(name: str, label: str, validator, fallback: str = "") -> str:
        value = usable_default(name, fallback)
        try:
            validator(value)
        except ValueError:
            return prompt_validated_value(label, validator)
        return value

    region = existing_or_prompt(
        "agentRegion", "OCI region used to package the browser agent", validate_agent_region
    )
    public_data_key = existing_or_prompt(
        "publicDataKey", "APM public data key", validate_public_data_key
    )
    upload_endpoint = existing_or_prompt(
        "uploadEndpoint", "APM data upload endpoint", validate_upload_endpoint
    )
    try:
        track_screen_text = parse_bool(existing.get("trackScreenText", False), "trackScreenText")
    except ValueError:
        track_screen_text = False
    try:
        track_plain_user_id = parse_bool(
            existing.get("trackPlainUserId", False), "trackPlainUserId"
        )
    except ValueError:
        track_plain_user_id = False
    candidate = {
        "agentRegion": region,
        "publicDataKey": public_data_key,
        "uploadEndpoint": upload_endpoint,
        "serviceName": usable_default("serviceName", "Fusion") or "Fusion",
        "webApplication": usable_default("webApplication", "RedwoodPage") or "RedwoodPage",
        "trackScreenText": track_screen_text,
        "trackPlainUserId": track_plain_user_id,
    }
    fusion_pod = existing.get("fusionPod")
    if isinstance(fusion_pod, str) and fusion_pod.strip():
        candidate["fusionPod"] = fusion_pod.strip()
    validate_config(candidate)
    agent_url(candidate, None)
    write_json(path, candidate)
    print(f"Saved configuration to {path}.\n")
    return candidate


def apply_cli_overrides(config: dict[str, object], args: argparse.Namespace) -> None:
    overrides = {
        "agentRegion": args.region,
        "publicDataKey": args.public_data_key,
        "uploadEndpoint": args.upload_endpoint,
        "serviceName": args.service_name,
        "webApplication": args.web_application,
        "trackScreenText": args.track_screen_text,
        "trackPlainUserId": args.track_plain_user_id,
    }
    config.update({key: value for key, value in overrides.items() if value is not None})


def fusion_catalog_url(pod: str) -> tuple[str, str]:
    """Return a validated Fusion pod name and its App UI catalog URL."""
    host = pod.strip().lower()
    host = re.sub(r"^https://", "", host)
    host = host.rstrip("/")
    if not re.fullmatch(r"[a-z0-9][a-z0-9.-]*[a-z0-9]", host) or "." not in host:
        raise ValueError("enter the Fusion pod host name, for example example.fa.us2.oraclecloud.com")
    return (
        host,
        f"https://{host}/fscmRestApi/vxmanifest/v2/digests/latest?type=app-ui-info",
    )


def prompt_fusion_pod(config: dict[str, object]) -> tuple[str, str]:
    existing = config.get("fusionPod")
    default = existing.strip() if isinstance(existing, str) else ""
    while True:
        pod = prompt_value("Fusion pod host name", default, required=True)
        try:
            return fusion_catalog_url(pod)
        except ValueError as error:
            print(f"That Fusion pod cannot be used: {error}")


def prompt_pillar() -> str:
    choices = ", ".join(PILLAR_LABELS)
    while True:
        pillar = input(f"Pillar to add ({choices}): ").strip().lower()
        if pillar in PILLAR_LABELS:
            return pillar
        print(f"Enter one of: {choices}.")


def configure_assistant_catalog(
    args: argparse.Namespace, config: dict[str, object], config_path: Path
) -> None:
    """Collect optional catalog choices for the double-click assistant only."""
    catalog_path = config_path.parent / "app-ui-info.json"
    print("\nFusion App UI scope")
    refresh = prompt_yes_no("Refresh the stored App UI catalog from Fusion", default=False)
    expand_pillar = prompt_yes_no(
        "Add all eligible App UIs in one Fusion pillar", default=False
    )
    if not refresh and not expand_pillar:
        print("Using only App UIs already present in the exported workspace.\n")
        return

    if refresh or not catalog_path.exists():
        if not catalog_path.exists() and not refresh:
            print("No stored App UI catalog was found, so it will be downloaded now.")
        pod, catalog_url = prompt_fusion_pod(config)
        config["fusionPod"] = pod
        write_json(config_path, config)
        args.app_ui_info_url = catalog_url
    else:
        args.app_ui_info_file = catalog_path

    if expand_pillar:
        args.pillar = prompt_pillar()
        print(
            f"The generated ZIP will add every eligible {PILLAR_LABELS[args.pillar]} App UI.\n"
        )
    else:
        print("The App UI catalog will be refreshed next to the configuration file.\n")


def safe_extract(archive: Path, destination: Path) -> bytes:
    with zipfile.ZipFile(archive) as source:
        archive_comment = source.comment
        for entry in source.infolist():
            parts = PurePosixPath(entry.filename).parts
            if entry.filename.startswith("/") or ".." in parts:
                raise ValueError(f"Unsafe ZIP entry: {entry.filename}")
        source.extractall(destination)
    return archive_comment


def find_extension_context(extracted: Path) -> ExtensionContext:
    candidates = sorted(
        list(extracted.glob("*/sources/extension.json"))
        + list(extracted.glob("*/sources/vb-extension.json"))
    )
    if len(candidates) != 1:
        found = ", ".join(path.relative_to(extracted).as_posix() for path in candidates)
        raise ValueError(
            "Expected exactly one extension manifest named extension.json or "
            f"vb-extension.json; found {len(candidates)}"
            + (f": {found}" if found else "")
        )

    manifest_path = candidates[0]
    manifest_bytes = manifest_path.read_bytes()
    try:
        manifest = json.loads(manifest_bytes)
    except json.JSONDecodeError as error:
        raise ValueError(f"Invalid JSON in {manifest_path}: {error}") from error
    if not isinstance(manifest, dict):
        raise ValueError(f"Expected a JSON object in {manifest_path}")

    extension_id = manifest.get("id")
    if not isinstance(extension_id, str) or not extension_id.strip():
        raise ValueError(f"Extension manifest {manifest_path} has no valid id")
    version_value = manifest.get("version", manifest.get("source.version", "unversioned"))
    extension_version = str(version_value)
    source_value = manifest.get("source.version")
    source_version = str(source_value) if source_value is not None else None

    return ExtensionContext(
        root=manifest_path.parent.parent,
        manifest_path=manifest_path,
        manifest_name=manifest_path.name,
        extension_id=extension_id,
        extension_version=extension_version,
        source_version=source_version,
        manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        manifest=manifest,
    )


def verify_manifest_unchanged(
    context: ExtensionContext, expected_sha256: str | None = None
) -> None:
    current_sha256 = hashlib.sha256(context.manifest_path.read_bytes()).hexdigest()
    expected = expected_sha256 or context.manifest_sha256
    if current_sha256 != expected:
        raise ValueError(
            f"Refusing to write output because {context.manifest_name} changed unexpectedly "
            "during generation"
        )


def validate_config(config: dict[str, object]) -> dict[str, object]:
    required = ("publicDataKey", "uploadEndpoint")
    for field in required:
        value = config.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"Configuration field {field!r} is required")
        if re.search(r"<[^>]+>", value):
            raise ValueError(
                f"Configuration field {field!r} still contains an example placeholder. "
                "Replace it with the value for the target environment."
            )

    endpoint = str(config["uploadEndpoint"]).rstrip("/")
    if not endpoint.startswith("https://"):
        raise ValueError("uploadEndpoint must use HTTPS")

    return {
        "publicDataKey": str(config["publicDataKey"]),
        "uploadEndpoint": endpoint,
        "serviceName": str(config.get("serviceName", "Fusion")),
        "webApplication": str(config.get("webApplication", "RedwoodPage")),
        "trackScreenText": parse_bool(
            config.get("trackScreenText", False), "trackScreenText"
        ),
        "trackPlainUserId": parse_bool(
            config.get("trackPlainUserId", False), "trackPlainUserId"
        ),
    }


def agent_url(config: dict[str, object], override: str | None) -> str:
    if override:
        return override
    if config.get("agentUrl"):
        return str(config["agentUrl"])
    region = str(config.get("agentRegion", "")).strip()
    if not re.fullmatch(r"[a-z]{2}-[a-z0-9-]+-[0-9]+", region):
        raise ValueError("Set agentRegion or agentUrl in the configuration")
    return (
        f"https://ingest-rum.apm-agt.{region}.oci.oraclecloud.com"
        f"/static/jslib/{AGENT_NAME}"
    )


def acquire_agent(
    target: Path,
    config: dict[str, object],
    url_override: str | None,
    file_override: Path | None,
) -> str:
    target.parent.mkdir(parents=True, exist_ok=True)
    if file_override:
        shutil.copyfile(file_override, target)
        source = str(file_override)
    else:
        source = agent_url(config, url_override)
        request = urllib.request.Request(source, headers={"User-Agent": "apm-rum-zip-generator"})
        with urllib.request.urlopen(request, timeout=60) as response, target.open("wb") as out:
            shutil.copyfileobj(response, out)

    size = target.stat().st_size
    if size < 10_000:
        raise ValueError(f"Downloaded agent is unexpectedly small ({size} bytes)")
    header = target.read_bytes()[:500].decode("utf-8", errors="ignore")
    if "apmrum.fus.base.combi.min.js" not in header:
        raise ValueError("Downloaded file does not look like the Fusion APM RUM agent")
    return source


def initialization_mode() -> str:
    value = os.environ.get(INITIALIZATION_MODE_ENV, "auto-import").strip().lower()
    aliases = {
        "auto": "auto-import",
        "auto-import": "auto-import",
        "vb-enter": "vb-enter",
        "vbenter": "vb-enter",
    }
    if value not in aliases:
        raise ValueError(
            f"{INITIALIZATION_MODE_ENV} must be auto-import or vb-enter, not {value!r}"
        )
    return aliases[value]


def render_module(config: dict[str, object], mode: str, agent_source: str) -> str:
    config_json = json.dumps(config, indent=4, ensure_ascii=False)
    indented_config = "\n".join(f"  {line}" for line in config_json.splitlines())
    embedded_agent = agent_source.rstrip() + "\n"
    auto_start = """
  // Importing this module at App UI scope activates APM RUM for that App UI.
  initializeConfigured();
""" if mode == "auto-import" else """
  // In fallback mode, an App UI vbEnter action chain calls initializeConfigured().
"""
    return f"""define([], () => {{
  'use strict';

  const LEGACY_SCRIPT_ELEMENT_ID = 'oracle-apm-rum-fusion-agent';
  const AGENT_LOADED_FLAG = '__oracleApmRumFusionAgentLoaded';
  const SHARED_CONFIG = Object.freeze(
{indented_config}
  );

  function configure(
    publicDataKey,
    uploadEndpoint,
    serviceName = 'Fusion',
    webApplication = 'RedwoodPage',
    trackScreenText = false,
    trackPlainUserId = false,
  ) {{
    if (!publicDataKey || !uploadEndpoint) {{
      throw new Error('APM RUM requires a public data key and data upload endpoint.');
    }}

    const apmRumConfig = document.apmrum || window.apmrum || {{}};
    // eslint-disable-next-line no-restricted-syntax
    document.apmrum = apmRumConfig;
    // eslint-disable-next-line no-restricted-syntax
    window.apmrum = apmRumConfig;

    apmRumConfig.custEP = apmRumConfig.custEP || {{}};
    apmRumConfig.custEP.OracleAPMPublicDataKey = publicDataKey;
    apmRumConfig.custEP.ociDataUploadEndpoint = uploadEndpoint.replace(/\\/$/, '');
    apmRumConfig.custEP.serviceName = serviceName || 'Fusion';
    apmRumConfig.custEP.webApplication = webApplication || 'RedwoodPage';
    apmRumConfig.custEP.trackPlainUserId = Boolean(trackPlainUserId);
    apmRumConfig.trackScreenText = Boolean(trackScreenText);
    apmRumConfig.traceSupportingEndpoints =
      apmRumConfig.traceSupportingEndpoints || [{{ headers: [], hostPattern: '.*' }}];
    apmRumConfig.confInst = (apmRumConfig.confInst || new Set()).add('custEP');
  }}

  function loadAgent() {{
    if (
      window[AGENT_LOADED_FLAG]
      || document.getElementById(LEGACY_SCRIPT_ELEMENT_ID)
      || document.ApmSdk
    ) {{
      return false;
    }}

    // Execute the packaged agent directly in this already-loaded module. Keeping
    // it inline avoids a second, cross-origin request to Preview resources.
    try {{
{embedded_agent}      window[AGENT_LOADED_FLAG] = true;
    }} catch (error) {{
      delete window[AGENT_LOADED_FLAG];
      throw error;
    }}
    return true;
  }}

  function initialize(
    publicDataKey,
    uploadEndpoint,
    serviceName = 'Fusion',
    webApplication = 'RedwoodPage',
    trackScreenText = false,
    trackPlainUserId = false,
  ) {{
    configure(
      publicDataKey,
      uploadEndpoint,
      serviceName,
      webApplication,
      trackScreenText,
      trackPlainUserId,
    );
    return loadAgent();
  }}

  function initializeConfigured() {{
    return initialize(
      SHARED_CONFIG.publicDataKey,
      SHARED_CONFIG.uploadEndpoint,
      SHARED_CONFIG.serviceName,
      SHARED_CONFIG.webApplication,
      SHARED_CONFIG.trackScreenText,
      SHARED_CONFIG.trackPlainUserId,
    );
  }}

{auto_start}
  return {{ initialize, initializeConfigured }};
}});
"""


def functions_metadata(mode: str) -> dict[str, object]:
    activation_description = (
        "Importing the module starts it automatically."
        if mode == "auto-import"
        else "An App UI vbEnter listener starts it in fallback mode."
    )
    return {
        "files": {
            MODULE_ALIAS: {
                "path": "apm/apmRum",
                "label": "APM Real User Monitoring",
                "description": (
                    "Configures APM RUM and executes the embedded Fusion browser agent. "
                    + activation_description
                ),
                "referenceable": "extension",
                "functions": {
                    "initializeConfigured": {
                        "label": "Initialize APM RUM with shared configuration",
                        "description": (
                            "Initializes APM RUM using the central configuration generated "
                            "in apmRum.js. No parameters are required."
                        ),
                        "params": {},
                        "return": "boolean",
                        "referenceable": "extension",
                    },
                    "initialize": {
                        "label": "Initialize APM RUM",
                        "description": "Initializes APM RUM with App UI-specific overrides.",
                        "params": {
                            "publicDataKey": {"label": "Public data key", "type": "string"},
                            "uploadEndpoint": {
                                "label": "Data upload endpoint",
                                "type": "string",
                            },
                            "serviceName": {
                                "label": "Service name",
                                "type": "string",
                                "defaultValue": "Fusion",
                            },
                            "webApplication": {
                                "label": "Web application",
                                "type": "string",
                                "defaultValue": "RedwoodPage",
                            },
                            "trackScreenText": {
                                "label": "Capture screen text",
                                "description": "May capture PII or sensitive business text.",
                                "type": "boolean",
                                "defaultValue": False,
                            },
                            "trackPlainUserId": {
                                "label": "Report plain user names",
                                "description": "Enable only after privacy and security review.",
                                "type": "boolean",
                                "defaultValue": False,
                            },
                        },
                        "return": "boolean",
                        "referenceable": "extension",
                    },
                },
            }
        }
    }


def read_json(path: Path, default: dict[str, object]) -> dict[str, object]:
    if not path.exists():
        return default
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def write_json(path: Path, value: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def remove_generated_listeners(app_dir: Path, model: dict[str, object]) -> int:
    removable: set[str] = set()
    for chain_id in ("vbEnterListener", VB_ENTER_CHAIN_ID):
        listener = app_dir / "chains" / f"{chain_id}.js"
        if not listener.exists():
            continue
        content = listener.read_text(encoding="utf-8")
        if re.search(r"\$modules\.apmRum\.initialize(?:Configured)?\(", content):
            removable.add(chain_id)

    if not removable:
        return 0

    listeners = model.get("eventListeners")
    if not isinstance(listeners, dict):
        return 0
    vb_enter = listeners.get("vbEnter")
    if not isinstance(vb_enter, dict) or not isinstance(vb_enter.get("chains"), list):
        return 0

    old_chains = vb_enter["chains"]
    new_chains = [
        chain
        for chain in old_chains
        if not isinstance(chain, dict)
        or chain.get("chain") not in removable
        and chain.get("chainId") not in removable
    ]
    if len(new_chains) == len(old_chains):
        return 0
    if new_chains:
        vb_enter["chains"] = new_chains
    else:
        listeners.pop("vbEnter", None)

    removed = len(old_chains) - len(new_chains)
    chains_dir = app_dir / "chains"
    for chain_id in removable:
        (chains_dir / f"{chain_id}.js").unlink(missing_ok=True)
    if chains_dir.exists() and not any(chains_dir.iterdir()):
        chains_dir.rmdir()
    return removed


def add_vb_enter_listener(app_dir: Path, model: dict[str, object]) -> None:
    listeners = model.setdefault("eventListeners", {})
    if not isinstance(listeners, dict):
        raise ValueError(f"eventListeners must be an object in {app_dir / 'app-x.json'}")
    vb_enter = listeners.setdefault("vbEnter", {"chains": []})
    if not isinstance(vb_enter, dict):
        raise ValueError(f"eventListeners.vbEnter must be an object in {app_dir / 'app-x.json'}")
    chains = vb_enter.setdefault("chains", [])
    if not isinstance(chains, list):
        raise ValueError(
            f"eventListeners.vbEnter.chains must be an array in {app_dir / 'app-x.json'}"
        )
    if not any(
        isinstance(chain, dict)
        and chain.get("chain", chain.get("chainId")) == VB_ENTER_CHAIN_ID
        for chain in chains
    ):
        chains.append({"parameters": {}, "chain": VB_ENTER_CHAIN_ID})

    chains_dir = app_dir / "chains"
    chains_dir.mkdir(parents=True, exist_ok=True)
    (chains_dir / f"{VB_ENTER_CHAIN_ID}.js").write_text(
        "define([\n"
        "  'vb/action/actionChain',\n"
        "  'vb/action/actions',\n"
        "  'vb/action/actionUtils',\n"
        "], (\n"
        "  ActionChain,\n"
        "  Actions,\n"
        "  ActionUtils\n"
        ") => {\n"
        "  'use strict';\n\n"
        f"  class {VB_ENTER_CHAIN_ID} extends ActionChain {{\n\n"
        "    /**\n"
        "     * @param {Object} context\n"
        "     */\n"
        "    async run(context) {\n"
        "      const { $modules } = context;\n"
        "      $modules.apmRum.initializeConfigured();\n"
        "    }\n"
        "  }\n\n"
        f"  return {VB_ENTER_CHAIN_ID};\n"
        "});\n",
        encoding="utf-8",
    )


def discover_applications(ui_root: Path, existing_only: bool) -> list[Path]:
    if existing_only:
        return sorted(path.parent for path in ui_root.glob("*/applications/*/app-x.json"))

    applications: set[Path] = set()
    for applications_dir in ui_root.glob("*/applications"):
        applications.update(path for path in applications_dir.iterdir() if path.is_dir())
    return sorted(applications)


def activate_applications(
    ui_root: Path, existing_only: bool, mode: str
) -> tuple[int, int, int]:
    created = 0
    updated = 0
    removed_listeners = 0
    for app_dir in discover_applications(ui_root, existing_only):
        model_path = app_dir / "app-x.json"
        existed = model_path.exists()
        model = read_json(
            model_path,
            {
                "description": "An App UI extension",
                "events": {},
                "types": {},
                "variables": {},
                "eventListeners": {},
            },
        )
        imports = model.setdefault("imports", {})
        if not isinstance(imports, dict):
            raise ValueError(f"imports must be an object in {model_path}")
        modules = imports.setdefault("modules", {})
        if not isinstance(modules, dict):
            raise ValueError(f"imports.modules must be an object in {model_path}")

        existing_alias = next(
            (
                alias
                for alias, metadata in modules.items()
                if isinstance(metadata, dict) and metadata.get("path") == MODULE_PATH
            ),
            None,
        )
        if existing_alias is None:
            if MODULE_ALIAS in modules:
                raise ValueError(
                    f"Module alias {MODULE_ALIAS!r} already has another path in {model_path}"
                )
            modules[MODULE_ALIAS] = {"path": MODULE_PATH}

        removed_listeners += remove_generated_listeners(app_dir, model)
        if mode == "vb-enter":
            add_vb_enter_listener(app_dir, model)
        write_json(model_path, model)

        module_path = app_dir / "app-x.js"
        if not module_path.exists():
            module_path.write_text(
                "define([], () => {\n"
                "  'use strict';\n\n"
                "  class AppModule {\n"
                "  }\n\n"
                "  return AppModule;\n"
                "});\n",
                encoding="utf-8",
            )
        if existed:
            updated += 1
        else:
            created += 1
    return created, updated, removed_listeners


def create_zip(
    source: Path, target: Path, comment: bytes, context: ExtensionContext
) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        identifier_comment = (
            f"APM RUM target: {context.identifier}; "
            f"manifest-format: {context.format_identifier}"
        ).encode("utf-8")
        original_comment = comment.rstrip()
        archive.comment = (
            original_comment + b"\n" + identifier_comment
            if original_comment
            else identifier_comment
        )
        for path in sorted(source.rglob("*")):
            if path.is_file() and path.resolve() != target.resolve():
                archive.write(path, path.relative_to(source).as_posix())


def resolve_input(path: Path | None) -> Path:
    if path is not None:
        return path

    candidates = sorted(DEFAULT_DOWNLOADS.glob("*.zip"))
    if not candidates:
        raise ValueError(
            f"No input ZIP was specified and {DEFAULT_DOWNLOADS} contains no ZIP files. "
            "Export the current Visual Builder extension into that directory, or use --input."
        )
    if len(candidates) > 1:
        if not sys.stdin.isatty():
            choices = ", ".join(candidate.name for candidate in candidates)
            raise ValueError(
                f"More than one input ZIP was found in {DEFAULT_DOWNLOADS}: {choices}. "
                "Select one with --input."
            )
        print("\nChoose the Fusion export to transform:")
        for index, candidate in enumerate(candidates, start=1):
            print(f"  {index}. {candidate.name}")
        while True:
            selected = input("Enter its number: ").strip()
            if selected.isdigit() and 1 <= int(selected) <= len(candidates):
                return candidates[int(selected) - 1]
            print(f"Enter a number from 1 to {len(candidates)}.")
    return candidates[0]


def resolve_output(input_path: Path, path: Path | None) -> Path:
    if path is not None:
        return path
    candidate = DEFAULT_OUTPUT / f"{input_path.stem}-with-apm-rum.zip"
    sequence = 2
    while candidate.exists():
        candidate = DEFAULT_OUTPUT / f"{input_path.stem}-with-apm-rum-{sequence}.zip"
        sequence += 1
    return candidate


def pillar_from_provider_id(provider_id: str) -> str | None:
    normalized = provider_id.strip().lower()
    for prefix, pillar in PROVIDER_PILLAR_PREFIXES:
        if normalized.startswith(prefix):
            return pillar
    return None


def normalize_explicit_pillar(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    aliases = {
        "cx": "cx",
        "customer experience": "cx",
        "erp": "erp",
        "enterprise resource planning": "erp",
        "hcm": "hcm",
        "human capital management": "hcm",
        "scm": "scm",
        "supply chain management": "scm",
    }
    return aliases.get(normalized)


def parse_app_ui_catalog(data: bytes, source: str) -> list[CatalogApplication]:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError(f"App UI catalog from {source} is not UTF-8 text") from error

    leading = text.lstrip()[:500].lower()
    if leading.startswith("<") or "<html" in leading or "<!doctype html" in leading:
        raise ValueError(
            f"{source} contains HTML instead of the App UI catalog. The Fusion server "
            "probably returned a sign-in page. Download the URL using an authenticated "
            "Fusion session, save it as downloads/app-ui-info.json, and rerun with "
            "--app-ui-info-file downloads/app-ui-info.json."
        )

    try:
        payload = json.loads(text)
    except json.JSONDecodeError as error:
        raise ValueError(
            f"Invalid App UI catalog JSON from {source}: line {error.lineno}, "
            f"column {error.colno}: {error.msg}"
        ) from error

    if not isinstance(payload, dict):
        raise ValueError(f"App UI catalog from {source} must contain a JSON object")
    digest = payload.get("digest")
    providers = digest.get("app-ui-info") if isinstance(digest, dict) else None
    if not isinstance(providers, list):
        raise ValueError(
            f"App UI catalog from {source} has no digest.app-ui-info provider list"
        )

    applications: list[CatalogApplication] = []
    for provider in providers:
        if not isinstance(provider, dict):
            continue
        provider_id = provider.get("id")
        provider_version = provider.get("version")
        metadata = provider.get("metadata")
        provider_apps = metadata.get("applications") if isinstance(metadata, dict) else None
        if (
            not isinstance(provider_id, str)
            or not provider_id.strip()
            or not isinstance(provider_version, str)
            or not provider_version.strip()
            or not isinstance(provider_apps, list)
        ):
            continue
        if not re.fullmatch(r"[A-Za-z0-9._-]+", provider_id):
            raise ValueError(
                f"App UI catalog from {source} contains an unsafe provider id: "
                f"{provider_id!r}"
            )

        for application in provider_apps:
            if not isinstance(application, dict):
                continue
            application_id = application.get("id")
            if not isinstance(application_id, str) or not application_id.strip():
                continue
            if not re.fullmatch(r"[A-Za-z0-9._-]+", application_id):
                raise ValueError(
                    f"App UI catalog from {source} contains an unsafe application id: "
                    f"{application_id!r}"
                )
            pillar = normalize_explicit_pillar(
                application.get("pillar") or application.get("extensionPillar")
            )
            if not pillar:
                continue
            url_id = application.get("urlId")
            display_name = application.get("displayName")
            applications.append(
                CatalogApplication(
                    provider_id=provider_id,
                    provider_version=provider_version,
                    application_id=application_id,
                    url_id=url_id if isinstance(url_id, str) else application_id,
                    display_name=(
                        display_name if isinstance(display_name, str) else application_id
                    ),
                    pillar=pillar,
                    extensible=application.get("extensible") is True,
                )
            )
    if not applications:
        raise ValueError(f"App UI catalog from {source} contains no usable applications")
    return applications


def load_app_ui_catalog(
    file_path: Path | None, url: str | None, save_path: Path | None = None
) -> tuple[list[CatalogApplication], str]:
    if file_path is not None:
        if not file_path.exists():
            raise ValueError(f"App UI catalog file does not exist: {file_path}")
        return parse_app_ui_catalog(file_path.read_bytes(), str(file_path)), str(file_path)

    if not url:
        raise ValueError("Select an App UI catalog with --app-ui-info-file or --app-ui-info-url")
    if not url.startswith("https://"):
        raise ValueError("--app-ui-info-url must use HTTPS")

    request = urllib.request.Request(url, headers={"User-Agent": "apm-rum-extension-generator"})
    with urllib.request.urlopen(request, timeout=60) as response:
        data = response.read()
        content_type = response.headers.get("Content-Type", "")
    if "text/html" in content_type.lower():
        raise ValueError(
            f"{url} returned HTML instead of the App UI catalog. The Fusion server "
            "probably returned a sign-in page. Download the URL using an authenticated "
            "Fusion session and use --app-ui-info-file."
        )

    applications = parse_app_ui_catalog(data, url)
    destination = save_path or DEFAULT_CATALOG
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    return applications, f"{url} (saved to {destination})"


def select_catalog_applications(
    applications: list[CatalogApplication], pillar: str, requested: list[str] | None = None
) -> list[CatalogApplication]:
    requested_keys: set[tuple[str, str]] = set()
    if requested:
        for value in requested:
            provider_id, separator, application_id = value.partition("/")
            if (
                separator != "/"
                or not provider_id
                or not application_id
                or "/" in application_id
            ):
                raise ValueError(
                    "Each --application value must be PROVIDER_ID/APPLICATION_ID; "
                    f"received {value!r}"
                )
            if application_id.strip().lower() in UNIFIED_MODULE_APPLICATION_IDS:
                raise ValueError(
                    "The unified-module Redwood application must not be customized with APM RUM"
                )
            requested_keys.add((provider_id, application_id))

    selected = sorted(
        (
            application
            for application in applications
            if application.pillar == pillar
            and application.extensible
            and application.application_id.strip().lower()
            not in UNIFIED_MODULE_APPLICATION_IDS
        ),
        key=lambda application: (application.provider_id, application.application_id),
    )
    if not selected:
        raise ValueError(
            f"The App UI catalog contains no extensible applications for pillar {pillar!r}"
        )

    if not requested:
        return selected

    selected_by_key = {
        (application.provider_id, application.application_id): application
        for application in selected
    }
    missing = sorted(requested_keys - selected_by_key.keys())
    if missing:
        choices = ", ".join(f"{provider}/{application}" for provider, application in missing)
        raise ValueError(
            "Requested --application value is not an extensible application in "
            f"pillar {pillar!r}: {choices}"
        )
    return [selected_by_key[key] for key in sorted(requested_keys)]


def create_catalog_application_directories(
    ui_root: Path, applications: list[CatalogApplication]
) -> tuple[int, int]:
    created = 0
    existing = 0
    for application in applications:
        if application.extensible is not True:
            raise ValueError(
                "Refusing to auto-create an App UI that is not explicitly marked "
                f"extensible=true: {application.provider_id}/{application.application_id}"
            )
        app_dir = (
            ui_root
            / application.provider_id
            / "applications"
            / application.application_id
        )
        if app_dir.exists():
            existing += 1
        else:
            app_dir.mkdir(parents=True, exist_ok=True)
            created += 1
    return created, existing


def numeric_version(value: object) -> tuple[int, ...] | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    if normalized.startswith(">="):
        normalized = normalized[2:]
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)*", normalized):
        return None
    return tuple(int(part) for part in normalized.split("."))


def merge_catalog_dependencies(
    context: ExtensionContext, applications: list[CatalogApplication]
) -> tuple[int, int, str]:
    verify_manifest_unchanged(context)
    manifest = context.manifest
    dependencies = manifest.setdefault("dependencies", [])
    if not isinstance(dependencies, list):
        raise ValueError(
            f"dependencies must be an array in {context.manifest_path}"
        )

    existing_by_id: dict[str, dict[str, object]] = {}
    for dependency in dependencies:
        if not isinstance(dependency, dict):
            raise ValueError(
                f"Every dependency must be an object in {context.manifest_path}"
            )
        dependency_id = dependency.get("id")
        if isinstance(dependency_id, str):
            existing_by_id[dependency_id] = dependency

    providers = {
        application.provider_id: application.provider_version
        for application in applications
    }
    added = 0
    updated = 0
    for provider_id, provider_version in sorted(providers.items()):
        required_version = f">={provider_version}"
        existing = existing_by_id.get(provider_id)
        if existing is None:
            dependency = {"id": provider_id, "version": required_version}
            dependencies.append(dependency)
            existing_by_id[provider_id] = dependency
            added += 1
        elif existing.get("version") != required_version:
            existing_version = numeric_version(existing.get("version"))
            catalog_version = numeric_version(provider_version)
            if (
                existing_version is None
                or catalog_version is None
                or existing_version < catalog_version
            ):
                existing["version"] = required_version
                updated += 1

    if added or updated:
        write_json(context.manifest_path, manifest)
    manifest_sha256 = hashlib.sha256(context.manifest_path.read_bytes()).hexdigest()
    return added, updated, manifest_sha256


def suggest_pillar(context: ExtensionContext) -> PillarSuggestion | None:
    manifest = context.manifest
    for field in ("pillar", "extensionPillar"):
        pillar = normalize_explicit_pillar(manifest.get(field))
        if pillar:
            return PillarSuggestion(pillar, "high", f"manifest field {field}")

    votes: list[tuple[str, str]] = []
    dependencies = manifest.get("dependencies")
    if isinstance(dependencies, list):
        for dependency in dependencies:
            if not isinstance(dependency, dict):
                continue
            provider_id = dependency.get("id")
            if not isinstance(provider_id, str):
                continue
            pillar = pillar_from_provider_id(provider_id)
            if pillar:
                votes.append((pillar, f"dependency {provider_id}"))

    ui_root = context.root / "sources" / "ui"
    if ui_root.exists():
        for namespace in ui_root.iterdir():
            if not namespace.is_dir() or namespace.name in {"base", "self"}:
                continue
            pillar = pillar_from_provider_id(namespace.name)
            if pillar:
                votes.append((pillar, f"source namespace {namespace.name}"))

    if votes:
        counts = Counter(pillar for pillar, _ in votes)
        ranked = counts.most_common()
        pillar, count = ranked[0]
        distribution = ", ".join(f"{name}={value}" for name, value in ranked)
        if len(ranked) == 1:
            return PillarSuggestion(
                pillar,
                "high",
                f"provider/dependency identifiers ({distribution})",
            )
        if count > ranked[1][1] and count / len(votes) >= 0.6:
            return PillarSuggestion(
                pillar,
                "medium",
                f"dominant provider/dependency identifiers ({distribution})",
            )

    descriptive_text = " ".join(
        str(manifest.get(field, "")) for field in ("id", "name", "description")
    ).lower()
    label_patterns = (
        ("hcm", r"(?:^|[ _-])hcm(?:$|[ _-])|human[ _-]+capital"),
        ("scm", r"(?:^|[ _-])scm(?:$|[ _-])|supply[ _-]+chain|procurement"),
        ("cx", r"(?:^|[ _-])cx(?:$|[ _-])|customer[ _-]+experience"),
        (
            "erp",
            r"(?:^|[ _-])erp(?:$|[ _-])|enterprise[ _-]+resource[ _-]+planning",
        ),
    )
    for pillar, pattern in label_patterns:
        if re.search(pattern, descriptive_text):
            return PillarSuggestion(
                pillar,
                "low",
                "extension id/name/description",
            )
    return None


def no_applications_warning(context: ExtensionContext) -> str:
    suggestion = suggest_pillar(context)
    lines = [
        "WARNING: No App UI application directories were detected in the input export.",
        "The generated ZIP contains the APM RUM resources, but it does not activate "
        "APM RUM in any App UI.",
    ]
    if suggestion:
        lines.append(
            f"Suggested pillar: {suggestion.label} [{suggestion.pillar}] "
            f"({suggestion.confidence} confidence; {suggestion.evidence})."
        )
        lines.append(
            f"Recommendation: review the environment's extensible {suggestion.label} "
            "App UIs, add the required App UI extension artifacts and provider "
            "dependencies, export the workspace again, and rerun the generator."
        )
        lines.extend(
            [
                "Recommended catalog-expansion rerun after confirming the pillar:",
                "  python3 scripts/generate-apm-rum-extension.py "
                f"--pillar {suggestion.pillar} --app-ui-info-url '{EXAMPLE_APP_UI_INFO_URL}'",
                "The EEHO host is an example; replace it with the Fusion pod that matches "
                "the input export when expanding another environment.",
                "This downloads the selected App UI catalog, adds its extensible applications "
                f"for pillar {suggestion.pillar}, merges their provider dependencies, and "
                "applies the shared APM RUM configuration to the generated App UI overrides.",
            ]
        )
    else:
        lines.append("Suggested pillar: unavailable; the ZIP contains no reliable pillar signal.")
        lines.append(
            "Recommendation: select the intended pillar in Visual Builder, add the "
            "required App UI extension artifacts and provider dependencies, export the "
            "workspace again, and rerun the generator."
        )
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Add a central APM RUM configuration and auto-starting module import "
            "to every App UI discovered in a Visual Builder extension export."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        help=(
            "Visual Builder export ZIP; when omitted, use the only ZIP in the "
            "project downloads directory"
        ),
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Generated export ZIP; defaults to the project output directory",
    )
    parser.add_argument(
        "--config",
        type=Path,
        help="APM RUM JSON config; defaults to config/apm-rum-config.json",
    )
    parser.add_argument(
        "--assistant",
        action="store_true",
        help="Use the interactive macOS/Windows assistant questions.",
    )
    parser.add_argument("--region", help="OCI region used to download the Fusion agent")
    parser.add_argument("--public-data-key", help="APM domain public data key")
    parser.add_argument("--upload-endpoint", help="APM domain data upload endpoint")
    parser.add_argument("--service-name", help="Service name reported to APM")
    parser.add_argument("--web-application", help="Web application name reported to APM")
    parser.add_argument(
        "--track-screen-text",
        choices=("true", "false"),
        help="Capture human-readable screen text (privacy-sensitive)",
    )
    parser.add_argument(
        "--track-plain-user-id",
        choices=("true", "false"),
        help="Report plain Fusion user names (privacy-sensitive)",
    )
    parser.add_argument("--agent-url", help="Override the agent download URL")
    parser.add_argument("--agent-file", type=Path, help="Use a local agent file instead")
    parser.add_argument(
        "--existing-apps-only",
        action="store_true",
        help="Patch only applications that already contain app-x.json",
    )
    parser.add_argument(
        "--pillar",
        choices=tuple(PILLAR_LABELS),
        help=(
            "Expand the export with every extensible catalog application in this pillar; "
            "requires an App UI catalog"
        ),
    )
    parser.add_argument(
        "--application",
        action="append",
        metavar="PROVIDER_ID/APPLICATION_ID",
        help=(
            "Add only this extensible catalog application (repeatable). Requires "
            "--pillar and an App UI catalog."
        ),
    )
    catalog = parser.add_mutually_exclusive_group()
    catalog.add_argument(
        "--app-ui-info-file",
        type=Path,
        help="Previously downloaded app-ui-info JSON catalog",
    )
    catalog.add_argument(
        "--app-ui-info-url",
        help="HTTPS app-ui-info catalog URL to download and save in downloads/",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.agent_url and args.agent_file:
        raise ValueError("Use only one of --agent-url and --agent-file")

    config_path = args.config if args.config is not None else DEFAULT_CONFIG
    raw_config = load_config(config_path)
    if args.assistant:
        configure_assistant_catalog(args, raw_config, config_path)

    has_catalog = args.app_ui_info_file is not None or args.app_ui_info_url is not None
    if args.pillar and not has_catalog:
        raise ValueError(
            "Use --pillar together with exactly one of --app-ui-info-file or "
            "--app-ui-info-url"
        )
    if args.application and not args.pillar:
        raise ValueError("--application requires --pillar and an App UI catalog")
    if args.pillar and args.existing_apps_only:
        raise ValueError(
            "--existing-apps-only cannot be combined with catalog pillar expansion"
        )

    apply_cli_overrides(raw_config, args)
    shared_config = validate_config(raw_config)

    input_path = resolve_input(args.input)
    output_path = resolve_output(input_path, args.output)

    if input_path.resolve() == output_path.resolve():
        raise ValueError("Input and output ZIP paths must be different")

    mode = initialization_mode()
    with tempfile.TemporaryDirectory(prefix="apm-rum-extension-") as temp_name:
        extracted = Path(temp_name)
        comment = safe_extract(input_path, extracted)
        extension_context = find_extension_context(extracted)
        extension_root = extension_context.root
        expected_manifest_sha256 = extension_context.manifest_sha256
        catalog_source = None
        catalog_applications = 0
        catalog_pillar_applications = 0
        catalog_eligible_applications = 0
        catalog_non_extensible = 0
        catalog_eligible_not_requested = 0
        catalog_directories_created = 0
        catalog_directories_existing = 0
        dependencies_added = 0
        dependencies_updated = 0

        if has_catalog and not args.pillar:
            _, catalog_source = load_app_ui_catalog(
                args.app_ui_info_file,
                args.app_ui_info_url,
                config_path.parent / "app-ui-info.json",
            )

        if args.pillar:
            catalog, catalog_source = load_app_ui_catalog(
                args.app_ui_info_file,
                args.app_ui_info_url,
                config_path.parent / "app-ui-info.json",
            )
            eligible = select_catalog_applications(catalog, args.pillar)
            selected = select_catalog_applications(catalog, args.pillar, args.application)
            catalog_applications = len(selected)
            catalog_pillar_applications = sum(
                application.pillar == args.pillar for application in catalog
            )
            catalog_eligible_applications = len(eligible)
            catalog_non_extensible = (
                catalog_pillar_applications - catalog_eligible_applications
            )
            catalog_eligible_not_requested = (
                catalog_eligible_applications - catalog_applications
            )
            (
                catalog_directories_created,
                catalog_directories_existing,
            ) = create_catalog_application_directories(
                extension_root / "sources" / "ui", selected
            )
            (
                dependencies_added,
                dependencies_updated,
                expected_manifest_sha256,
            ) = merge_catalog_dependencies(extension_context, selected)

        resources = extension_root / "sources" / "ui" / "self" / "resources" / "functions"
        apm_dir = resources / "apm"
        source = acquire_agent(
            apm_dir / AGENT_NAME,
            raw_config,
            args.agent_url,
            args.agent_file,
        )
        agent_path = apm_dir / AGENT_NAME
        try:
            agent_source = agent_path.read_text(encoding="utf-8")
        except UnicodeDecodeError as error:
            raise ValueError(
                "The Fusion APM RUM agent must be UTF-8 JavaScript"
            ) from error
        agent_path.unlink()
        (apm_dir / "apmRum.js").write_text(
            render_module(shared_config, mode, agent_source), encoding="utf-8"
        )
        write_json(resources / "functions.json", functions_metadata(mode))

        detected_applications = discover_applications(
            extension_root / "sources" / "ui", existing_only=False
        )
        created, updated, removed = activate_applications(
            extension_root / "sources" / "ui", args.existing_apps_only, mode
        )
        activation_warning = (
            no_applications_warning(extension_context)
            if not detected_applications
            else None
        )
        verify_manifest_unchanged(extension_context, expected_manifest_sha256)
        create_zip(extracted, output_path, comment, extension_context)

    print(f"Input: {input_path}")
    print(f"Configuration: {config_path}")
    print(f"Created {output_path}")
    print(f"Extension: {extension_context.identifier}")
    print(
        f"Manifest: {extension_context.manifest_name} "
        f"({extension_context.format_identifier}, "
        + (
            f"catalog dependencies added={dependencies_added}, updated={dependencies_updated})"
            if args.pillar
            else "preserved unchanged)"
        )
    )
    if args.pillar:
        print(f"Catalog: {catalog_source}")
        print(f"Expansion pillar: {args.pillar}")
        print(f"Catalog applications found in pillar: {catalog_pillar_applications}")
        if args.application:
            print(f"Requested catalog applications: {len(set(args.application))}")
        print(
            "Catalog applications selected (extensible=true): "
            f"{catalog_applications}"
        )
        print(
            "Catalog applications skipped (extensible is not true): "
            f"{catalog_non_extensible}"
        )
        if args.application:
            print(
                "Catalog applications left out by --application selection "
                f"(extensible=true): {catalog_eligible_not_requested}"
            )
        print(f"Application directories created: {catalog_directories_created}")
        print(f"Application directories already present: {catalog_directories_existing}")
    elif catalog_source:
        print(f"App UI catalog refreshed: {catalog_source}")
    print(f"Initialization mode: {mode}")
    print(f"Agent source: {source}")
    print(f"Applications created: {created}")
    print(f"Applications updated: {updated}")
    if removed:
        print(f"Generated vbEnter listeners removed: {removed}")
    if activation_warning:
        sys.stdout.flush()
        print(activation_warning, file=sys.stderr)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError, zipfile.BadZipFile) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(1)
