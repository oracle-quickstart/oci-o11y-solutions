#!/bin/bash
# Double-click this file on macOS after unzipping the assistant.
set -u

SCRIPT_DIRECTORY="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIRECTORY" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required to run the Fusion APM RUM Assistant."
  echo "Install Python 3, then double-click this file again."
  read -r -n 1 -p "Press any key to close..."
  exit 1
fi

python3 scripts/generate-apm-rum-extension.py --assistant
RESULT=$?
echo
if [ "$RESULT" -eq 0 ]; then
  echo "Done. Import the ZIP shown above from the output folder into Visual Builder."
else
  echo "No ZIP was created. Read the message above, correct the issue, and try again."
fi
read -r -n 1 -p "Press any key to close..."
exit "$RESULT"
