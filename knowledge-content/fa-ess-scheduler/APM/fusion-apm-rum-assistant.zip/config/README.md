# Configuration

Keep the supplied `apm-rum-config.example.json` unchanged as the reusable
source example. When no `apm-rum-config.json` exists, the macOS and Windows
assistant launchers ask for the required values and create it automatically.
You do not need to copy or edit the example file for normal use.

The first-run screen lists where to find the required values in the OCI APM
domain: the **Public Data Key** is under **Domain details > Data Keys**, and
the **Data upload endpoint** is in the domain details. Screen-text capture and
plain user-name reporting are not offered in the assistant and remain disabled
until an approved administrator edits this file.

When the assistant downloads an App UI catalog for pillar expansion, it stores
the catalog as `app-ui-info.json` next to this configuration file. It also
stores the selected Fusion pod host in the local configuration so a later
refresh can reuse it.

The generator uses `apm-rum-config.json` automatically. A different file can
be selected with `--config`.

The user configuration can contain environment-specific identifiers and must
not be committed or shared without the appropriate review.
