# APM RUM global-function package

This package stores the Fusion APM RUM browser-agent library inside the Visual
Builder extension. The complete extension generator embeds the library directly
in the `apmRum` global-function module, so runtime initialization makes no
second request for an agent file from Preview, `static.oracle.com`, or an
`ingest-rum` endpoint.

For first-use discovery, pillar selection, initial deployment, changes-only
maintenance, and post-upgrade re-discovery, see
[Phased APM RUM rollout for Fusion App UIs](PHASED-APPROACH.md).

Command examples use `python3` and POSIX line continuations. On Windows, use
`py` and enter multi-line examples as one line in PowerShell.

## Generate a complete multi-App-UI extension

For an existing Visual Builder extension export, the generator can download the
regional Fusion agent, create one central configuration, and activate that
configuration in every App UI found in the export:

```sh
python3 scripts/generate-apm-rum-extension.py \
  --input downloads/fusion-extension-export.zip \
  --config config/apm-rum-config.json \
  --output output/fusion-extension-with-apm-rum.zip
```

Copy the example configuration to `config/apm-rum-config.json` and adjust the
copy before generating a distributable archive. `agentRegion` selects where the current
`apmrum.fus.base.combi.min.js` is downloaded and embedded into the generated
`apmRum.js`; `uploadEndpoint` selects the APM domain that receives the telemetry.
They do not have to be in the same region.
The source example contains placeholders and keeps both privacy-sensitive
capture options disabled. Enable either option only after the required privacy
review.

Command-line values can override individual values from the copied configuration:

```sh
python3 scripts/generate-apm-rum-extension.py \
  --input downloads/fusion-extension-export.zip \
  --output output/fusion-extension-with-apm-rum.zip \
  --region eu-paris-1 \
  --public-data-key '<public data key>' \
  --upload-endpoint 'https://<domain>.apm-agt.<region>.oci.oraclecloud.com' \
  --service-name Fusion \
  --web-application RedwoodPage \
  --track-screen-text false \
  --track-plain-user-id false
```

Command-line values override matching values in `--config`, which makes it easy
to keep a shared baseline while changing one deployment setting.

### Extension manifest compatibility

The generator accepts either supported extension manifest filename:

- `extension1/sources/extension.json` identifies the legacy/migrated export
  format.
- `extension1/sources/vb-extension.json` identifies the newer export format.

Exactly one must be present. An archive containing both is rejected before any
output is written, preventing the colliding-manifest preview failure. During a
normal generation, the selected manifest is preserved byte-for-byte. Explicit
`--pillar` catalog expansion keeps the same manifest filename and fields but
rewrites the JSON to merge the selected App UIs' provider dependencies. It does
not remove unrelated dependencies.

The manifest `id`, `version`, and optional `source.version` form a generation
identifier such as `site_hcm_extension@0.1+source.2607`. The identifier and
manifest format are printed by the generator and stored in the generated ZIP
comment, making it possible to tell which extension context an archive targets
without changing the extension JSON itself.

By default, the generator finds application directories already represented in
the export, including applications that only contain page or layout changes. It
creates missing `app-x.js` and `app-x.json` extension artifacts, then adds this
declarative application-level import:

```json
"imports": {
  "modules": {
    "apmRum": {
      "path": "self:$functions/apmRum"
    }
  }
}
```

Loading that module configures APM RUM and executes the embedded Fusion agent.
It does not create a script element or request a second protected Preview
resource, so no `$extension.path` expression, AppModule constructor, action
chain, or lifecycle listener is required. Existing JSON and JavaScript are
merged and preserved. A document-wide marker and compatibility checks for an
older script-element installation prevent duplicate agent initialization.
Recognizable APM-only `vbEnterListener` chains from the earlier approach are
removed because they would be redundant; unrelated listeners are preserved.

Use `--existing-apps-only` to limit generation to applications that already
have an `app-x.json`. Use `--agent-file` for an offline build or `--agent-url`
to override the URL derived from `agentRegion`.

### Long-term fallback: App UI `vbEnter` listeners

The default `auto-import` mode has no action chains. If a future Visual Builder
runtime stops executing imported modules eagerly, regenerate the archive with
this environment variable:

```sh
APM_RUM_INITIALIZATION_MODE=vb-enter \
python3 scripts/generate-apm-rum-extension.py \
  --input downloads/fusion-extension-export.zip \
  --config config/apm-rum-config.json \
  --output output/fusion-extension-with-apm-rum-vb-enter.zip
```

On Windows PowerShell, set `$env:APM_RUM_INITIALIZATION_MODE = 'vb-enter'`, run
the generator with `py`, and remove the temporary setting afterward with
`Remove-Item Env:APM_RUM_INITIALIZATION_MODE`.

This switch is intentionally not exposed as a normal command-line option. It
disables module side-effect initialization and generates an App UI-level
`vbEnter` listener named `apmRumVbEnterListener` in every selected application.
Each listener calls the same central, parameterless
`$modules.apmRum.initializeConfigured()` function. The APM configuration and
packaged agent therefore remain centralized; only the activation mechanism
changes.

Unset `APM_RUM_INITIALIZATION_MODE`, or set it to `auto-import`, to return to
the default approach. The generator removes its own obsolete APM listeners when
switching modes, while preserving unrelated `vbEnter` chains.

## Refresh the packaged browser agent

Before distributing or importing the ZIP, download the latest Fusion library
from the ingest endpoint in the customer's preferred OCI region:

```sh
python3 scripts/build-apm-rum-resources.py eu-paris-1
```

The script also accepts the full ingest base URL:

```sh
python3 scripts/build-apm-rum-resources.py \
  https://ingest-rum.apm-agt.eu-paris-1.oci.oraclecloud.com
```

It replaces
`functions/apm/apmrum.fus.base.combi.min.js` and rebuilds
`output/apm-rum-functions.zip`. The ingest endpoint is automatically updated by the
APM team, so run the script again whenever a newer agent should be packaged.

Do not use the example Paris endpoint blindly. Select the OCI region approved
for the deployment and verify that the downloaded response is the expected
JavaScript library.

## Import and initialize

The build script creates two archives in `output/` for different import mechanisms:

- `apm-rum-functions.zip` is the documented Visual Builder resource archive.
  Import it through the extension-level **Resources** folder. Visual Builder
  places its top-level `functions` directory under
  `extension1/sources/ui/self/resources/`.
- `apm-rum-extension-resources.zip` is pre-positioned for a source-root upload
  or source-control merge. It already contains
  `extension1/sources/ui/self/resources/functions/...`. Do not import this
  archive through the **Resources** import dialog, because that would add an
  extra nested `extension1` directory beneath Resources.

After either method, Source view must show the resources under
`extension1/sources/ui/self/resources/functions`; a repository-root `functions`
folder is not a registered extension resource.

For `apm-rum-functions.zip`, start the import on the extension-level Resources
folder and verify that the import location is
`extension1/sources/ui/self/resources`:

![Visual Builder Resources context menu](images/visual-builder-resource-import-menu.png)

![Visual Builder resource import dialog](images/visual-builder-resource-import-dialog.png)

Then initialize the function in each target App UI:

1. Open the target App UI (Fusion module), then its **Event Listeners** tab.
2. Add a listener for the `vbEnter` lifecycle event and create an App UI-level
   action chain.
3. In the action chain, add **Call Function** and select
   **Initialize APM RUM**. Selecting it should import the module automatically.
4. Supply the public data key and data upload endpoint. For **Extension resource
   path**, click **fx** and enter the expression `$extension.path`. Do not type
   `$extension.path` into a plain text-value field: Visual Builder will pass it
   literally and the browser will request a URL containing the characters
   `$extension.path`. Keep the default service and web application names for
   the first test. The function also exposes two optional privacy-sensitive
   Boolean settings:

   - **Capture screen text** (`trackScreenText`): captures document titles and
     clicked-element text to produce more human-readable APM attributes. It is
     disabled by default because these values can contain PII or sensitive
     business data.
   - **Report plain user names** (`trackPlainUserId`): reports Fusion user names
     in plain text instead of their default hashed representation. It is
     disabled by default and should only be enabled after privacy and security
     review.

   When an updated `functions.json` adds parameters, Visual Builder normally
   adds them automatically to existing **Initialize APM RUM** Call Function
   actions. If new parameters do not appear, refresh or reopen the designer.
   Removing and re-adding the Call Function action is a troubleshooting fallback,
   not a normal upgrade step.
5. Preview or publish the extension and verify the expected browser-agent
   request and RUM uploads.

## Configure once for multiple App UIs

The parameterized **Initialize APM RUM** function is useful for an initial test
or when different App UIs must use different APM settings. Repeating the same
key, endpoint, names, and privacy settings in every App UI is harder to maintain.

When all monitored App UIs should use the same settings:

1. Open `functions/apm/apmRum.js` and edit the `SHARED_CONFIG` block once:

   ```javascript
   const SHARED_CONFIG = Object.freeze({
     publicDataKey: '<public data key>',
     uploadEndpoint: '<APM data upload endpoint>',
     serviceName: 'Fusion',
     webApplication: 'RedwoodPage',
     trackScreenText: false,
     trackPlainUserId: false,
   });
   ```

2. In each App UI's `vbEnter` action chain, select **Initialize APM RUM with
   shared configuration**.
3. Bind its only parameter, **Extension resource path**, with the fx expression
   `$extension.path`.

Every App UI then references the same extension-level configuration. Updating
and reimporting `apmRum.js` changes the settings in one place. Keep the original
parameterized function for an App UI that needs an override.

An empty call to the parameterized function, `$modules.apmRum.initialize()`, is
not a valid shared-configuration call: it does not provide the required APM
domain or extension resource path. Use `initializeConfigured($extension.path)`
for the shared mode.

The initialization function writes the configuration before it appends the
locally packaged script. It also assigns a stable ID to the script element so
re-entering an App UI does not load a second copy.

The deployment-specific base URL is deliberately not hard-coded. Visual Builder
evaluates `$extension.path` for Preview, Share, and published deployments. The
initializer only hard-codes the package-owned suffix:

```text
resources/functions/apm/apmrum.fus.base.combi.min.js
```

## Manual acceptance checks

- After uploading the ZIP or committing its source changes, allow 5–10 minutes
  for Visual Builder and Fusion to build, deploy, and propagate the overrides
  before deciding that Preview has failed.
- The browser-agent script is requested exactly once from the extension's own
  deployed resources.
- `window.apmrum` and `document.apmrum` reference the same object.
- `custEP` contains the expected data key, endpoint, service, and web app.
- Navigation among several pages in the App UI produces RUM activity.
- Leaving and re-entering the App UI does not add another script element.
- No request for the browser-agent library is made to `static.oracle.com` or an
  `ingest-rum` host.
- A CSP failure is not present in the browser console. The data upload endpoint
  still needs to be permitted for RUM uploads.

A 404 observed immediately after an upload or commit can be a transient
readiness or stale-client-cache result. Wait for propagation first. If the 404
continues, use the Visual Builder environment's **Clear Client Cache** option,
reload, wait for the environment to become ready, and test again. Escalate to
provider mapping, missing flow resources, or archive structure only when the
request remains reproducibly wrong after those steps.

If the App UI does not expose an App UI-scoped `vbEnter` listener in the target
Fusion environment, record that as the deciding result. The resource archive
only makes the function available; it cannot initialize itself without a
supported caller.
