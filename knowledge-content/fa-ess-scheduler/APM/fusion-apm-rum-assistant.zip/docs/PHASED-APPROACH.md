# Phased APM RUM rollout for Fusion App UIs

This approach separates application discovery from generation and deployment.
The separation is important because a Fusion environment can advertise hundreds
of App UIs, while an extension should normally remain scoped to one functional
pillar and only the applications that are useful to its users.

The APM RUM generator activates applications already represented in an exported
extension. With an explicitly confirmed pillar and an `app-ui-info` catalog, it
can also add selected extensible applications and merge their provider
dependencies. The generated ZIP is the reviewable artifact: import it into a
non-production workspace and validate it before publishing.

Command examples use `python3` and POSIX line continuations. On Windows, use
`py` and enter a multi-line example as one line in PowerShell unless the example
specifically shows PowerShell syntax.

## Phase 1: Capture a baseline

1. Export the current Visual Builder workspace into `downloads/`. Treat this
   ZIP as the source of truth for the run; do not start from an older generated
   archive.
2. Keep an untouched copy for rollback.
3. Copy `config/apm-rum-config.example.json` to
   `config/apm-rum-config.json` and enter the deployment's APM domain, public
   data key, download region, and privacy settings.
4. Keep `trackScreenText` and `trackPlainUserId` set to `false` unless their use
   has completed the required privacy and security review.

The generator accepts either `extension.json` or `vb-extension.json` and must
continue to preserve whichever format the export uses. An archive containing
both manifests is invalid.

Use the top-right Visual Builder menu for both Export and the later Import:

![Visual Builder menu with Export highlighted](images/visual-builder-import-export-menu.png)

## Phase 2: Discover the environment's App UIs

The Fusion runtime provides an `app-ui-info` catalog containing provider
extension IDs and versions, App UI IDs and URL IDs, display names, pillars, and
an `extensible` flag. Replace `<fusion-host>` with the host name of the target
Fusion pod:

```sh
curl --fail --location \
  --url 'https://<fusion-host>/fscmRestApi/vxmanifest/v2/digests/latest?type=app-ui-info' \
  --output downloads/app-ui-info.json
```

For example, the two environments examined during development use:

```sh
curl --fail --location \
  --url 'https://fa-evwb-saasfademo1.ds-fa.oraclepdemos.com/fscmRestApi/vxmanifest/v2/digests/latest?type=app-ui-info' \
  --output downloads/app-ui-info.json
```

```sh
curl --fail --location \
  --url 'https://eeho.fa.us2.oraclecloud.com/fscmRestApi/vxmanifest/v2/digests/latest?type=app-ui-info' \
  --output downloads/app-ui-info.json
```

The endpoint may require an authenticated Fusion session. If command-line
`curl` receives a sign-in page instead of JSON, open the endpoint in an
authenticated browser and either save the response or use the browser's
developer tools to copy the successful request as cURL. Do not store or share
the resulting command because it can contain session cookies or authorization
headers. A saved HAR can help locate and extract the JSON response after it has
been handled according to the organization's rules for authentication data;
the generator itself accepts the extracted JSON file.
On Windows, use `curl.exe` if PowerShell maps `curl` to a different command.

The generator can download the catalog when the URL is accessible from the
command line. It validates the response and saves it as
`downloads/app-ui-info.json`:

```sh
python3 scripts/generate-apm-rum-extension.py \
  --pillar hcm \
  --app-ui-info-url 'https://eeho.fa.us2.oraclecloud.com/fscmRestApi/vxmanifest/v2/digests/latest?type=app-ui-info'
```

EEHO is an example. Use the Fusion pod matching the input extension export. If
the request returns a sign-in page, download the catalog through an authenticated
session and use `--app-ui-info-file downloads/app-ui-info.json` instead.

Catalog parsing detects an HTML document before JSON decoding and reports a
specific error such as:

```text
downloads/app-ui-info.json contains HTML instead of the App UI catalog. The Fusion server
probably returned a sign-in page. Download the URL using an authenticated Fusion
session and try again.
```

Other malformed content produces a normal JSON validation error.

The discovery step should validate that the result is JSON and has this general
shape before using it:

```text
digest.app-ui-info[]
  id                         provider extension ID
  version                    provider extension version
  metadata.applications[]
    id                       App UI ID
    urlId                    App UI URL segment
    displayName              translated display name
    pillar                   functional pillar
    extensible               whether the App UI exposes extension points
```

This endpoint was observed in the supplied environment traffic, but it is not
currently documented as a public Visual Builder API. Discovery tooling should
therefore accept a saved JSON response or HAR as well as optional live
retrieval, and should fail with a clear message if the response shape changes.

## Phase 3: Infer and confirm the pillar

Staying within a pillar is the safest initial scope. It limits overrides and
matches the way Visual Builder groups extensions and App UIs. Pillar detection
should use evidence in this order:

1. **High confidence: existing application artifacts.** Map App UI directories
   already present below `sources/ui/*/applications/` to catalog entries and
   use their catalog pillar.
2. **High confidence: declared dependencies.** Map dependency IDs from the
   extension manifest to catalog providers. If all relevant dependencies map
   to one pillar, suggest that pillar.
3. **Medium confidence: dominant dependency pillar.** When dependencies span
   pillars, report the counts and suggest a dominant pillar only for review.
   Do not silently discard the outliers.
4. **Low confidence: extension ID or name.** Values such as
   `site_hcm_extension` and `HCM Extension` can suggest HCM, but they are
   user-controlled labels rather than a formal pillar declaration.
5. **No evidence:** require an explicit pillar selection.

The clean HCM sample export contains no applications, dependencies, or formal
pillar property. Its ID and name suggest HCM, but automation should display
`Suggested pillar: Human Capital Management (HCM) [hcm] (low confidence)` and
require confirmation. By contrast, the CX Sales sample contains the `cx-sales`
App UI and CX provider dependencies, which provide high-confidence catalog
evidence.

The current generator applies this deduction when it detects no application
directories. It warns that the generated ZIP contains resources only, prints
the suggested pillar and confidence, and recommends adding reviewed App UIs and
their provider dependencies before exporting and running the generator again.
The warning also prints a ready-to-adapt command containing the suggested
`--pillar` and the EEHO `--app-ui-info-url` example.

Pillar inference is a guardrail, not a proof that every App UI in the pillar is
useful. Oracle documents that Visual Builder can show other extensions from the
same pillar even though they are not actual dependencies.

## Phase 4: Perform the initial installation

For the initial rollout, generate a complete extension archive from the latest
export and the reviewed plan:

```sh
python3 scripts/generate-apm-rum-extension.py \
  --input downloads/fusion-extension-export.zip \
  --config config/apm-rum-config.json \
  --agent-file downloads/apmrum.fus.base.combi.min.js \
  --output output/fusion-extension-with-apm-rum.zip
```

For an export without application artifacts, add the confirmed pillar, catalog,
and only the reviewed App UIs. Do not add `unified-module`; Fusion does not
support customizing it:

```sh
python3 scripts/generate-apm-rum-extension.py \
  --input downloads/fusion-extension-export.zip \
  --config config/apm-rum-config.json \
  --pillar hcm \
  --app-ui-info-file downloads/app-ui-info.json \
  --application oracle_hcm_absencesUI/absences \
  --application oracle_hcm_goalsUI/goals \
  --output output/fusion-extension-with-apm-rum.zip
```

The generator creates an override directory for every selected extensible
application, creates its `app-x.js` and `app-x.json`, imports the shared APM
RUM module, and merges the containing provider extension into the existing
manifest dependencies. It preserves the input manifest filename and unrelated
manifest fields and dependencies. Selection requires the catalog's exact
`extensible` field to contain the JSON Boolean `true`; `false`, missing, and
string values are skipped and reported separately.

Import the complete generated archive or commit the generated source changes,
then wait 5–10 minutes before previewing. Visual Builder and Fusion apply App UI
overrides asynchronously; a large pillar-wide extension can require more time
than a small diagnostic extension. Previewing too soon can temporarily resolve
an older provider resource or return a 404 even though the generated override
is valid.

If a 404 remains after the delay, use the Visual Builder environment's **Clear
Client Cache** option, reload the environment, wait for it to become ready, and
retry. Only investigate the ZIP structure or provider mapping after the same
failure reproduces with a fresh client cache. Do not repeatedly reimport or
commit the same archive while the preceding change may still be propagating.

After the readiness check, preview the extension, inspect the build logs, and
verify several App UIs before publishing. Keep the baseline ZIP, discovery
catalog, configuration, generated ZIP, and validation result together as the
deployment record.

## Phase 5: Routine maintenance

For an agent or configuration update:

1. Export the current workspace again. This incorporates Visual Builder
   migrations and changes made since the preceding run.
2. Reuse the confirmed pillar and reviewed application selection from the
   previous plan.
3. Download the current Fusion APM RUM agent from the approved OCI region, or
   let the generator download it.
4. Generate against the new export; never patch the old generated ZIP in place.
5. Import the newly generated ZIP into a non-production workspace and validate it.
6. After the upload or commit, wait 5–10 minutes for the overrides to propagate.
   If a 404 persists, use **Clear Client Cache**, reload, and retry after the
   environment is ready.
7. Preview, inspect network requests and console output, and publish only after
   the acceptance checks pass.

If the working branch is no longer available, Visual Builder can create a new
workspace by importing the currently deployed extension from the Fusion
environment. Select the correct environment, sandbox, extension, and deployed
version rather than recreating the extension from an unrelated template:

![Import a deployed extension from Oracle Cloud Applications](images/visual-builder-import-from-environment.png)

After importing an older extension, Visual Builder can request a migration or
dependency upgrade. Complete and commit that migration, export the migrated
workspace, and only then run the APM RUM generator:

![Visual Builder migration warning after import](images/visual-builder-migration-warning.png)

### Full archive

The full generated archive is the authoritative and recoverable result. Use it
for the initial installation, after Visual Builder migrations, after changing
the selected application set, or whenever cleanup/removal is required.

Use the Visual Builder import flow for the target environment and validate the
result before publishing. Keep the untouched workspace export so the change can
be rolled back if validation does not succeed.

## Phase 6: Re-discover after Fusion changes

Repeat discovery after a quarterly Fusion upgrade, the enablement of another
Fusion offering, or a significant change in business usage. Compare the new
catalog with the stored catalog and plan, restricted to the confirmed pillar.
Report:

- newly available extensible App UIs;
- App UIs or providers that disappeared or are no longer extensible;
- provider version changes;
- selected dependencies that no longer resolve;
- applications newly requested by the business.

Do not automatically activate every new catalog entry. Preserve the existing
selection, present additions as candidates, and generate a new full archive
after approved scope changes.

## References

- [What Are Dependencies?](https://docs.oracle.com/en/cloud/paas/visual-builder/visualbuilder-building-appui/what-are-dependencies.html)
- [Add a Dependency](https://docs.oracle.com/en/cloud/paas/visual-builder/visualbuilder-building-appui/add-dependency.html)
- [Files in Source View](https://docs.oracle.com/en/cloud/paas/visual-builder/visualbuilder-building-appui/files-source-view.html)
- [Import Resources to Your Workspace](https://docs.oracle.com/en/cloud/paas/visual-builder/visualbuilder-building-appui/import-resources-your-workspace.html)
- [Export Your Workspace as an Archive](https://docs.oracle.com/en/cloud/paas/visual-builder/visualbuilder-building-appui/export-your-workspace-archive.html)
