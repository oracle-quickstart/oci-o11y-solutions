# Fusion APM RUM Assistant

Use this folder to create a Fusion Visual Builder import ZIP with APM Real User
Monitoring enabled. No JavaScript or JSON editing is needed.

1. Extract `fusion-apm-rum-assistant.zip` to a private folder.
2. In Visual Builder, export the current workspace and keep that ZIP unchanged
   as your rollback copy.
3. Copy the export ZIP into the extracted assistant's `downloads` folder.
4. Start the assistant:

   - **macOS:** double-click **Fusion APM RUM Assistant.command**.
   - **Windows:** double-click **Fusion APM RUM Assistant.bat**.

5. On the first run, enter the OCI region, APM public data key, and APM data
   upload endpoint. The screen explains where to find each value in the APM
   domain. Privacy collection remains disabled.
6. Choose whether to refresh the stored Fusion App UI catalog. If a catalog is
   needed, enter the Fusion pod host name; the assistant downloads and stores
   the catalog beside its configuration file.
7. Choose whether to add all eligible App UIs in one pillar. The default is
   **No**. If you choose **Yes**, select HCM, CX, ERP, or SCM.
8. If several exports are present, choose the one you want to transform.
9. Import the generated ZIP from the `output` folder into the same Visual
   Builder workspace.
10. Wait 5–10 minutes, then preview the Redwood app and confirm that RUM data
   appears in APM before publishing.

The assistant needs Python 3. If the launcher says it is unavailable, ask your
local IT team to install Python 3 and then run the launcher again.

Keep the original Fusion export and the generated ZIP until validation is
complete. The generated ZIP contains deployment-specific APM settings; do not
share it outside the approved deployment process.
