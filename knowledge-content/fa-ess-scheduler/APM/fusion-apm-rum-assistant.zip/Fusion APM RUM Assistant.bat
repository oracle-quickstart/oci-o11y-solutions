@echo off
REM Double-click this file on Windows after unzipping the assistant.
cd /d "%~dp0"

py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 scripts\generate-apm-rum-extension.py --assistant
  goto finished
)

python --version >nul 2>&1
if not errorlevel 1 (
  python scripts\generate-apm-rum-extension.py --assistant
  goto finished
)

echo Python 3 is required to run the Fusion APM RUM Assistant.
echo Install Python 3, then double-click this file again.

:finished
echo.
echo The generated ZIP, if successful, is in the output folder.
pause
