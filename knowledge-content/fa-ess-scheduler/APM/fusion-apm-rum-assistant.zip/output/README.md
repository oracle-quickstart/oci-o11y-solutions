# Output

Generated archives are written here. The complete archive whose name ends in
`-with-apm-rum.zip` is the normal file to upload through Visual Builder's
top-right **Import** command.

The assistant never overwrites an existing generated archive. A later run adds
`-2`, `-3`, and so on to the filename.

Keep the corresponding untouched input export until preview and publication
have succeeded. Generated ZIPs are ignored by Git by default.
