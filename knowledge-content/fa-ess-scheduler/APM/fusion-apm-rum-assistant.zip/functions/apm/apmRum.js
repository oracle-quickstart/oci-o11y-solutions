define([], () => {
  'use strict';

  const SCRIPT_ELEMENT_ID = 'oracle-apm-rum-fusion-agent';

  // Edit these values once when every monitored App UI should report to the
  // same APM domain with the same privacy settings. Use the parameterized
  // initialize function instead when an App UI needs different values.
  const SHARED_CONFIG = Object.freeze({
    publicDataKey: '',
    uploadEndpoint: '',
    serviceName: 'Fusion',
    webApplication: 'RedwoodPage',
    trackScreenText: false,
    trackPlainUserId: false,
  });

  function initialize(
    publicDataKey,
    uploadEndpoint,
    extensionPath,
    serviceName = 'Fusion',
    webApplication = 'RedwoodPage',
    trackScreenText = false,
    trackPlainUserId = false,
  ) {
    if (!publicDataKey || !uploadEndpoint || !extensionPath) {
      throw new Error(
        'APM RUM requires a public data key, data upload endpoint, and extension resource path.',
      );
    }

    if (extensionPath.includes('$extension.path')) {
      throw new Error(
        'The extension resource path was passed as literal text. Bind $extension.path with the Visual Builder fx expression editor.',
      );
    }

    const normalizedEndpoint = uploadEndpoint.replace(/\/$/, '');
    const normalizedExtensionPath = extensionPath.endsWith('/')
      ? extensionPath
      : `${extensionPath}/`;
    const apmRumConfig = document.apmrum || window.apmrum || {};

    // Keep both supported names pointed at the same configuration object.
    // eslint-disable-next-line no-restricted-syntax
    document.apmrum = apmRumConfig;
    // eslint-disable-next-line no-restricted-syntax
    window.apmrum = apmRumConfig;

    apmRumConfig.custEP = apmRumConfig.custEP || {};
    apmRumConfig.custEP.OracleAPMPublicDataKey = publicDataKey;
    apmRumConfig.custEP.ociDataUploadEndpoint = normalizedEndpoint;
    apmRumConfig.custEP.serviceName = serviceName || 'Fusion';
    apmRumConfig.custEP.webApplication = webApplication || 'RedwoodPage';
    apmRumConfig.custEP.trackPlainUserId = Boolean(trackPlainUserId);

    // Screen text is a shared browser-agent setting. It can capture document
    // titles and text associated with clicked elements, which may contain PII.
    apmRumConfig.trackScreenText = Boolean(trackScreenText);

    apmRumConfig.traceSupportingEndpoints =
      apmRumConfig.traceSupportingEndpoints || [
        { headers: [], hostPattern: '.*' },
      ];

    apmRumConfig.confInst =
      (apmRumConfig.confInst || new Set()).add('custEP');

    // vbEnter can run again after leaving and re-entering an App UI.
    if (document.getElementById(SCRIPT_ELEMENT_ID)) {
      return false;
    }

    const apmRumScript = document.createElement('script');
    apmRumScript.id = SCRIPT_ELEMENT_ID;
    apmRumScript.async = true;
    apmRumScript.crossOrigin = 'anonymous';
    // $extension.path supplies the deployment-specific base. This suffix is
    // stable because it describes the layout owned by this resource package.
    apmRumScript.src = `${normalizedExtensionPath}resources/functions/apm/apmrum.fus.base.combi.min.js`;

    document.head.appendChild(apmRumScript);
    return true;
  }

  function initializeConfigured(extensionPath) {
    return initialize(
      SHARED_CONFIG.publicDataKey,
      SHARED_CONFIG.uploadEndpoint,
      extensionPath,
      SHARED_CONFIG.serviceName,
      SHARED_CONFIG.webApplication,
      SHARED_CONFIG.trackScreenText,
      SHARED_CONFIG.trackPlainUserId,
    );
  }

  return { initialize, initializeConfigured };
});
