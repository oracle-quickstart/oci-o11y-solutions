Content
Sources: [omc_ociAuditLogSource]
Parsers: [Unified IAM Audit Log Format V2]

Reference
Functions: [Geolocation, Lookup]
Fields: [actntype, app, apptype, availdomain, cityclnt, cloudevntsver, comment, compartmentid, compartmentname, continentclnt, continentcodeclnt, contszin, contszout, countryclnt, countrycodeclnt, createdbyid, desc, ecidid, endeventtime, event, eventid, eventsrc, eventtype, eventtypever, geolocclnt, lastmodbyid, loggingloggrpocid, loggingrecid, mbody, method, msecactordisplayname, msecactorid, msecactortype, msecaddlattrs, msecdestaddlattrs, msecdestdomain, msecdestrsrcname, msecdestrsrctype, msecdesturl, msecrsrcname, msecrsrctype, msecsrcip, msg, newval, opcreqid, originator, path, principal, prog, provider, providertype, query, referr, regionclnt, regioncodeclnt, reqid, rsrcid, srcip, ssocompletedfactors, ssomatchedsignonpolicy, ssomatchedsignonrule, ssosessid, starteventtime, statecurr, stateprev, status, tenant, time, type, usrag, usrname]
Lookups: [omc_audit_api_names]
