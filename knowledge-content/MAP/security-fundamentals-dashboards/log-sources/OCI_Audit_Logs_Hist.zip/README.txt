Content
Sources: [OCI_Audit_Logs_Hist]
Parsers: [OCI Audit hist logs]

Reference
Parsers: [oci_audit_unifmt_logtype]
Fields: [mbody, time]
